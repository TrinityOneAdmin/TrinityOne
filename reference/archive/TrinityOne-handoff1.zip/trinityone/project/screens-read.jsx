// screens-read.jsx — the Bible reader (highlighting, word study, cross-refs, commentary, parallel)
const { useState: useS, useEffect: useE, useRef: useR } = React;

const HL_COLORS = [
  { id: 'yellow', v: 'var(--hl-yellow)' },
  { id: 'green', v: 'var(--hl-green)' },
  { id: 'pink', v: 'var(--hl-pink)' },
  { id: 'blue', v: 'var(--hl-blue)' },
  { id: 'clay', v: 'var(--hl-clay)' },
];

// ── verse text with tappable Strong's-tagged words ──
function VerseText({ text, tags, onWord, showStrongs }) {
  const map = {};
  Object.keys(tags || {}).forEach(k => { if (tags[k]) map[k.toLowerCase()] = tags[k]; });
  const tokens = text.match(/[A-Za-z']+|[^A-Za-z']+/g) || [text];
  return tokens.map((tok, i) => {
    const id = map[tok.toLowerCase()];
    if (id) {
      return (
        <span key={i} onClick={(e) => { e.stopPropagation(); onWord(id); }} style={{
          color: 'var(--clay-ink)', cursor: 'pointer', fontWeight: 500,
          borderBottom: '1.5px dotted color-mix(in oklab, var(--clay) 55%, transparent)',
        }}>
          {tok}{showStrongs ? <sup style={{ fontSize: '.62em', color: 'var(--clay)', fontWeight: 700, fontFamily: 'var(--font-ui)' }}> {id.replace('G','')}</sup> : null}
        </span>
      );
    }
    return <span key={i}>{tok}</span>;
  });
}

function VerseRow({ n, text, tags, hl, note, bookmarked, selected, onSelect, onWord, showStrongs, compact }) {
  return (
    <span style={{ position: 'relative' }}>
      <span onClick={() => onSelect(n)} style={{
        cursor: 'pointer', borderRadius: 6,
        outline: selected ? '2px solid var(--clay)' : 'none', outlineOffset: 3,
        background: selected ? 'color-mix(in oklab, var(--clay) 8%, transparent)' : 'transparent',
        transition: 'background .2s',
      }}>
        <sup style={{
          fontFamily: 'var(--font-ui)', fontSize: compact ? '.62em' : '.58em', fontWeight: 700,
          color: bookmarked ? 'var(--clay)' : 'var(--ink-3)', marginRight: 3, verticalAlign: 'super',
          position: 'relative', top: '-.1em',
        }}>{n}</sup>
        <span style={hl ? {
          background: hl, borderRadius: 3, padding: '1px 1px',
          WebkitBoxDecorationBreak: 'clone', boxDecorationBreak: 'clone',
        } : null}>
          <VerseText text={text} tags={tags} onWord={onWord} showStrongs={showStrongs} />
        </span>
        {note ? <Icon name="note" size={compact ? 12 : 14} color="var(--gold)" style={{ verticalAlign: 'middle', marginLeft: 4 }} /> : null}
      </span>{' '}
    </span>
  );
}

// ── header ──
function ReadHeader({ ctx, loc, version, onBook, onVersion, onSettings, compare, onCompare }) {
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20, paddingTop: 50,
      background: 'color-mix(in oklab, var(--paper) 88%, transparent)',
      backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)',
      borderBottom: '1px solid var(--line-2)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px 11px' }}>
        <button onClick={onBook} style={{
          display: 'flex', alignItems: 'center', gap: 6, border: 'none', cursor: 'pointer',
          background: 'var(--surface)', boxShadow: 'var(--shadow)', borderRadius: 13, padding: '9px 13px',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--ink)',
        }}>{loc.book} {loc.ch}<Icon name="chevD" size={15} stroke={2.2} color="var(--ink-3)" /></button>
        <button onClick={onVersion} style={{
          border: '1px solid var(--line)', cursor: 'pointer', background: 'var(--surface)',
          borderRadius: 13, padding: '9px 12px', fontWeight: 700, fontSize: 13, color: 'var(--clay)',
          boxShadow: 'var(--shadow)',
        }}>{version}</button>
        <div style={{ flex: 1 }} />
        <IconBtn name="compare" onClick={onCompare} style={compare ? { background: 'var(--clay)', color: '#fff', borderColor: 'var(--clay)' } : {}} />
        <IconBtn name="sliders" onClick={onSettings} />
      </div>
    </div>
  );
}

// ── verse action sheet ──
function ActionSheet({ v, ctx, open, onClose, onColor, curColor, onNote, onCross, onCommentary, onWord, bookmarked }) {
  if (v == null) return null;
  const acts = [
    { ic: 'pen', label: 'Note', fn: onNote },
    { ic: 'bookmark', label: bookmarked ? 'Saved' : 'Bookmark', fn: ctx._bm, active: bookmarked },
    { ic: 'copy', label: 'Copy', fn: ctx._copy },
    { ic: 'share', label: 'Share', fn: ctx._share },
    { ic: 'link', label: 'Cross-refs', fn: onCross },
    { ic: 'comment', label: 'Commentary', fn: onCommentary },
  ];
  return (
    <BottomSheet open={open} onClose={onClose}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>Verse selected</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>John 1:{v}</div>
        </div>
        <IconBtn name="x" onClick={onClose} />
      </div>
      {/* highlight colors */}
      <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-2)', marginBottom: 9 }}>Highlight</div>
      <div style={{ display: 'flex', gap: 11, marginBottom: 20 }}>
        {HL_COLORS.map(c => (
          <button key={c.id} onClick={() => onColor(curColor === c.v ? null : c.v)} style={{
            width: 44, height: 44, borderRadius: 999, background: c.v, cursor: 'pointer',
            border: curColor === c.v ? '2.5px solid var(--ink)' : '2px solid var(--line)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{curColor === c.v ? <Icon name="check" size={18} stroke={2.6} color="var(--ink)" /> : null}</button>
        ))}
        <button onClick={() => onColor(null)} style={{
          width: 44, height: 44, borderRadius: 999, background: 'var(--surface-2)', cursor: 'pointer',
          border: '2px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-3)',
        }}><Icon name="x" size={18} /></button>
      </div>
      {/* actions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
        {acts.map(a => (
          <button key={a.label} onClick={a.fn} style={{
            border: '1px solid var(--line)', background: a.active ? 'var(--clay-soft)' : 'var(--surface-2)',
            borderRadius: 16, padding: '14px 6px', cursor: 'pointer', display: 'flex',
            flexDirection: 'column', alignItems: 'center', gap: 7, color: a.active ? 'var(--clay-ink)' : 'var(--ink)',
          }}>
            <Icon name={a.ic} size={21} fill={a.active} /><span style={{ fontSize: 12, fontWeight: 600 }}>{a.label}</span>
          </button>
        ))}
      </div>
    </BottomSheet>
  );
}

// ── word study ──
function WordStudySheet({ id, open, onClose }) {
  const e = id ? window.LumenData.LEXICON[id] : null;
  return (
    <BottomSheet open={open} onClose={onClose}>
      {e ? <div style={{ paddingBottom: 6 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--clay)', fontWeight: 700, letterSpacing: '.5px' }}>STRONG'S {id} · GREEK</div>
            <div style={{ fontFamily: 'var(--font-read)', fontSize: 38, fontWeight: 500, lineHeight: 1.1, marginTop: 4 }}>{e.lemma}</div>
            <div style={{ fontSize: 16, color: 'var(--ink-2)', fontStyle: 'italic', fontFamily: 'var(--font-read)' }}>{e.translit} · <span style={{ fontStyle: 'normal', fontFamily: 'var(--font-ui)', fontSize: 13 }}>{e.pos}</span></div>
          </div>
          <IconBtn name="x" onClick={onClose} />
        </div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'var(--clay-soft)', color: 'var(--clay-ink)',
          padding: '6px 12px', borderRadius: 999, fontSize: 13, fontWeight: 700, margin: '16px 0 14px' }}>
          <Icon name="sparkle" size={15} stroke={2} /> {e.short}
        </div>
        <p style={{ fontFamily: 'var(--font-read)', fontSize: 18, lineHeight: 1.6, color: 'var(--ink)', margin: '0 0 18px', textWrap: 'pretty' }}>{e.gloss}</p>
        <div style={{ display: 'flex', gap: 10 }}>
          <div style={{ flex: 1, background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 16, padding: '13px 15px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--clay)' }}>{e.occ}</div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-2)', fontWeight: 600 }}>occurrences in the NT</div>
          </div>
          <button style={{ flex: 1, background: 'var(--ink)', color: 'var(--paper)', border: 'none', borderRadius: 16,
            cursor: 'pointer', fontWeight: 700, fontSize: 14, fontFamily: 'var(--font-ui)', display: 'flex',
            flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center', padding: '13px 15px', gap: 2 }}>
            <Icon name="study" size={18} color="var(--paper)" /> See all uses
          </button>
        </div>
      </div> : null}
    </BottomSheet>
  );
}

// ── cross refs ──
function CrossRefSheet({ v, open, onClose, ctx }) {
  const refs = (v != null && window.LumenData.CROSSREFS[v]) || [];
  return (
    <BottomSheet open={open} onClose={onClose}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <div><div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>Cross references</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>John 1:{v}</div></div>
        <IconBtn name="x" onClick={onClose} />
      </div>
      {refs.length ? refs.map((r, i) => (
        <div key={i} onClick={() => ctx.toast('Opening ' + r.ref)} style={{
          padding: '14px 0', borderTop: i ? '1px solid var(--line)' : 'none', cursor: 'pointer',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontWeight: 700, color: 'var(--clay)', fontSize: 14 }}>{r.ref}</span>
            <Icon name="chevR" size={16} color="var(--ink-3)" />
          </div>
          <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, lineHeight: 1.5, color: 'var(--ink)', margin: '5px 0 0' }}>{r.text}</p>
        </div>
      )) : <p style={{ color: 'var(--ink-2)', fontFamily: 'var(--font-read)', fontSize: 16, padding: '8px 0 16px' }}>No cross references for this verse yet.</p>}
    </BottomSheet>
  );
}

// ── commentary ──
function CommentarySheet({ open, onClose }) {
  const C = window.LumenData.COMMENTARY;
  return (
    <BottomSheet open={open} onClose={onClose} maxHeight="82%">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div><div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>{C.source}</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>John 1 · Commentary</div></div>
        <IconBtn name="x" onClick={onClose} />
      </div>
      {C.blocks.map((b, i) => (
        <div key={i} style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, marginBottom: 5 }}>
            <span style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 12, color: '#fff', background: 'var(--clay)', padding: '3px 9px', borderRadius: 8 }}>v{b.v}</span>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{b.title}</span>
          </div>
          <p style={{ fontFamily: 'var(--font-read)', fontSize: 16.5, lineHeight: 1.62, color: 'var(--ink)', margin: 0, textWrap: 'pretty' }}>{b.text}</p>
        </div>
      ))}
    </BottomSheet>
  );
}

// ── note editor ──
function NoteEditor({ v, open, onClose, value, onSave }) {
  const [text, setText] = useS(value || '');
  useE(() => { setText(value || ''); }, [value, open]);
  return (
    <BottomSheet open={open} onClose={onClose}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div><div style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>Note on</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>John 1:{v}</div></div>
        <button onClick={() => onSave(text)} style={{ border: 'none', background: 'var(--clay)', color: '#fff',
          padding: '10px 18px', borderRadius: 13, fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Save</button>
      </div>
      <textarea autoFocus value={text} onChange={e => setText(e.target.value)} placeholder="What is God showing you here?" style={{
        width: '100%', minHeight: 150, border: '1px solid var(--line)', borderRadius: 16, background: 'var(--surface-2)',
        padding: 15, fontFamily: 'var(--font-read)', fontSize: 17, lineHeight: 1.5, color: 'var(--ink)', resize: 'none', outline: 'none',
      }} />
    </BottomSheet>
  );
}

// ── version sheet ──
function VersionSheet({ open, onClose, version, onPick }) {
  const vs = window.LumenData.CHAPTER.versions;
  return (
    <BottomSheet open={open} onClose={onClose}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, marginBottom: 12 }}>Translation</div>
      {Object.keys(vs).map((k, i) => (
        <button key={k} onClick={() => onPick(k)} style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '14px 4px', borderTop: i ? '1px solid var(--line)' : 'none', background: 'none', border: 'none',
          cursor: 'pointer', color: 'var(--ink)', textAlign: 'left',
        }}>
          <div><div style={{ fontWeight: 700, fontSize: 15 }}>{k}</div>
          <div style={{ fontSize: 13, color: 'var(--ink-2)' }}>{vs[k].name}</div></div>
          {version === k ? <Icon name="check" size={20} stroke={2.4} color="var(--clay)" /> : null}
        </button>
      ))}
    </BottomSheet>
  );
}

// ── reader settings ──
function SettingsSheet({ open, onClose, scale, setScale, serif, setSerif, showStrongs, setShowStrongs }) {
  return (
    <BottomSheet open={open} onClose={onClose}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, marginBottom: 16 }}>Reading</div>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink-2)', marginBottom: 9 }}>Text size</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontFamily: 'var(--font-read)', fontSize: 15 }}>A</span>
          <input type="range" min="0.85" max="1.45" step="0.05" value={scale} onChange={e => setScale(parseFloat(e.target.value))}
            style={{ flex: 1, accentColor: 'var(--clay)' }} />
          <span style={{ fontFamily: 'var(--font-read)', fontSize: 26 }}>A</span>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
        {[['Serif', true], ['Sans', false]].map(([lbl, val]) => (
          <button key={lbl} onClick={() => setSerif(val)} style={{
            flex: 1, padding: '13px', borderRadius: 14, cursor: 'pointer',
            border: serif === val ? '2px solid var(--clay)' : '1px solid var(--line)',
            background: serif === val ? 'var(--clay-soft)' : 'var(--surface-2)',
            color: serif === val ? 'var(--clay-ink)' : 'var(--ink-2)', fontWeight: 700, fontSize: 15,
            fontFamily: val ? 'var(--font-read)' : 'var(--font-ui)',
          }}>{lbl}</button>
        ))}
      </div>
      <button onClick={() => setShowStrongs(!showStrongs)} style={{
        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px', borderRadius: 14, border: '1px solid var(--line)', background: 'var(--surface-2)',
        cursor: 'pointer', color: 'var(--ink)',
      }}>
        <span style={{ fontWeight: 600, fontSize: 15 }}>Show Strong's numbers</span>
        <div style={{ width: 46, height: 28, borderRadius: 999, background: showStrongs ? 'var(--clay)' : 'var(--line)', position: 'relative', transition: 'background .2s' }}>
          <div style={{ position: 'absolute', top: 3, left: showStrongs ? 21 : 3, width: 22, height: 22, borderRadius: 999, background: '#fff', transition: 'left .2s', boxShadow: '0 1px 3px rgba(0,0,0,.2)' }} />
        </div>
      </button>
    </BottomSheet>
  );
}

// ── book picker overlay ──
function BookPicker({ open, onClose, onPick }) {
  const B = window.LumenData.BOOKS;
  const [sel, setSel] = useS(null);
  useE(() => { if (!open) setSel(null); }, [open]);
  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 52 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px 12px' }}>
          <IconBtn name="x" onClick={onClose} />
          <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700 }}>{sel ? sel.name : 'Books'}</h1>
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }}>
        {!sel ? ['ot', 'nt'].map(g => (
          <div key={g} style={{ marginBottom: 18 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.6px', margin: '4px 0 10px' }}>{g === 'ot' ? 'OLD TESTAMENT' : 'NEW TESTAMENT'}</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {B.filter(b => b.group === g).map(b => (
                <button key={b.abbr} onClick={() => setSel(b)} style={{
                  padding: '12px 16px', borderRadius: 14, border: '1px solid var(--line)', background: 'var(--surface)',
                  cursor: 'pointer', fontWeight: 600, fontSize: 15, color: 'var(--ink)', fontFamily: 'var(--font-ui)', boxShadow: 'var(--shadow)',
                }}>{b.name}</button>
              ))}
            </div>
          </div>
        )) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 9 }}>
            {Array.from({ length: sel.ch }, (_, i) => i + 1).map(c => {
              const live = sel.name === 'John' && c === 1;
              return (
                <button key={c} onClick={() => { if (live) { onPick(sel, c); } else { onPick(sel, c, true); } }} style={{
                  aspectRatio: '1', borderRadius: 13, border: live ? '2px solid var(--clay)' : '1px solid var(--line)',
                  background: live ? 'var(--clay-soft)' : 'var(--surface)', cursor: 'pointer',
                  fontWeight: 700, fontSize: 15, color: live ? 'var(--clay-ink)' : 'var(--ink)', fontFamily: 'var(--font-display)',
                }}>{c}</button>
              );
            })}
          </div>
        )}
      </div>
    </Overlay>
  );
}

// ── main read screen ──
function ReadScreen({ ctx }) {
  const CH = window.LumenData.CHAPTER;
  const [version, setVersion] = useS('KJV');
  const [compare, setCompare] = useS(false);
  const [scale, setScale] = useS(1.08);
  const [serif, setSerif] = useS(true);
  const [showStrongs, setShowStrongs] = useS(false);
  const [sel, setSel] = useS(null);          // selected verse num
  const [sheet, setSheet] = useS(null);       // 'action'|'word'|'cross'|'commentary'|'note'|'version'|'settings'|'book'
  const [wordId, setWordId] = useS(null);

  const verses = CH.versions[version].verses;
  const cmpVerses = CH.versions[compare === true ? 'WEB' : compare]?.verses || CH.versions.WEB.verses;

  const close = () => { setSheet(null); };
  const selectVerse = (n) => { setSel(n); setSheet('action'); };
  const openWord = (id) => { setWordId(id); setSheet('word'); };

  // wire action-sheet shortcuts onto ctx-like object
  const sheetCtx = {
    toast: ctx.toast,
    _bm: () => { ctx.toggleBookmark(sel); ctx.toast(ctx.bookmarks.includes(sel) ? 'Bookmark removed' : 'Bookmarked'); },
    _copy: () => { close(); ctx.toast('Copied to clipboard'); },
    _share: () => { close(); ctx.openShare({ ref: `John 1:${sel}`, text: verses[sel-1], version }); },
  };

  const readFont = serif ? 'var(--font-read)' : 'var(--font-ui)';
  const rs = ctx.readScale || 1;
  const baseSize = (serif ? 21 : 18) * scale * rs;

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <ReadHeader ctx={ctx} loc={{ book: CH.book, ch: CH.ch }} version={version}
        onBook={() => setSheet('book')} onVersion={() => setSheet('version')}
        onSettings={() => setSheet('settings')} compare={compare} onCompare={() => setCompare(c => c ? false : 'WEB')} />

      <ScreenScroll top={112} bottom={100}>
        <div style={{ animation: 'lumenFade .4s ease both' }}>
          <div style={{ textAlign: 'center', marginBottom: 22 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--clay)', letterSpacing: '1.5px', textTransform: 'uppercase' }}>Chapter {CH.ch}</div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 27, fontWeight: 700, margin: '6px 0 0', letterSpacing: '-.4px' }}>{CH.heading}</h1>
            <div style={{ width: 40, height: 3, borderRadius: 2, background: 'var(--clay)', margin: '14px auto 0', opacity: .5 }} />
          </div>

          {!compare ? (
            <p style={{ fontFamily: readFont, fontSize: baseSize, lineHeight: 1.78, color: 'var(--ink)', margin: 0, textWrap: 'pretty' }}>
              {verses.map((t, i) => (
                <VerseRow key={i} n={i+1} text={t} tags={window.LumenData.TAGS[i+1]}
                  hl={ctx.highlights[i+1]} note={ctx.notes[i+1]} bookmarked={ctx.bookmarks.includes(i+1)}
                  selected={sel === i+1} onSelect={selectVerse} onWord={openWord} showStrongs={showStrongs} />
              ))}
            </p>
          ) : (
            <div>
              {verses.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, padding: '11px 0', borderBottom: '1px solid var(--line-2)' }}>
                  <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 12, color: 'var(--ink-3)', width: 18, flexShrink: 0, paddingTop: 5 }}>{i+1}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--clay)', letterSpacing: '.5px', marginBottom: 2 }}>{version}</div>
                    <p style={{ fontFamily: readFont, fontSize: 16 * scale * rs, lineHeight: 1.55, margin: 0, color: 'var(--ink)' }}>{t}</p>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--sage)', letterSpacing: '.5px', marginBottom: 2 }}>WEB</div>
                    <p style={{ fontFamily: readFont, fontSize: 16 * scale * rs, lineHeight: 1.55, margin: 0, color: 'var(--ink-2)' }}>{cmpVerses[i]}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* footer nav */}
          <div style={{ display: 'flex', gap: 10, marginTop: 26 }}>
            <button onClick={() => ctx.toast('Previous chapter')} style={navBtnStyle}>
              <Icon name="chevL" size={16} /> Luke 24
            </button>
            <button onClick={() => ctx.toast('Next chapter')} style={{ ...navBtnStyle, color: 'var(--clay)', fontWeight: 700 }}>
              John 2 <Icon name="chevR" size={16} />
            </button>
          </div>
        </div>
      </ScreenScroll>

      <ActionSheet v={sel} ctx={sheetCtx} open={sheet === 'action'} onClose={close}
        curColor={ctx.highlights[sel]} onColor={(c) => { ctx.setHighlight(sel, c); }}
        bookmarked={ctx.bookmarks.includes(sel)}
        onNote={() => setSheet('note')} onCross={() => setSheet('cross')} onCommentary={() => setSheet('commentary')} />
      <WordStudySheet id={wordId} open={sheet === 'word'} onClose={close} />
      <CrossRefSheet v={sel} open={sheet === 'cross'} onClose={() => setSheet('action')} ctx={ctx} />
      <CommentarySheet open={sheet === 'commentary'} onClose={() => setSheet('action')} />
      <NoteEditor v={sel} open={sheet === 'note'} value={ctx.notes[sel]} onClose={() => setSheet('action')}
        onSave={(t) => { ctx.setNote(sel, t); setSheet('action'); ctx.toast('Note saved'); }} />
      <VersionSheet open={sheet === 'version'} onClose={close} version={version} onPick={(k) => { setVersion(k); close(); }} />
      <SettingsSheet open={sheet === 'settings'} onClose={close} scale={scale} setScale={setScale}
        serif={serif} setSerif={setSerif} showStrongs={showStrongs} setShowStrongs={setShowStrongs} />
      <BookPicker open={sheet === 'book'} onClose={close}
        onPick={(b, c, demo) => { close(); ctx.toast(demo ? `${b.name} ${c} — demo loads John 1` : `${b.name} ${c}`); }} />
    </div>
  );
}

const navBtnStyle = {
  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
  padding: '13px', borderRadius: 15, border: '1px solid var(--line)', background: 'var(--surface)',
  cursor: 'pointer', color: 'var(--ink-2)', fontWeight: 600, fontSize: 14, fontFamily: 'var(--font-ui)', boxShadow: 'var(--shadow)',
};

Object.assign(window, { ReadScreen });
