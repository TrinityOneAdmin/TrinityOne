// identity.jsx — onboarding, profile sheet, member card
const { useState: useId, useEffect: useIdE } = React;

// ════════ First-run identity moment ════════
function IdentityOnboarding({ open, identity, onSave, onSkip }) {
  const D = window.LumenData;
  const [name, setName] = useId('');
  const [av, setAv] = useId({ kind: 'symbol', color: '#5E8C6A', symbol: 'olive' });
  useIdE(() => { if (open) { setName(''); setAv({ kind: 'symbol', color: '#5E8C6A', symbol: 'olive' }); } }, [open]);
  if (!open) return null;

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 70, background: 'var(--paper)', display: 'flex', flexDirection: 'column',
      animation: 'lumenFade .4s ease both' }}>
      {/* warm header */}
      <div style={{ paddingTop: 64, paddingBottom: 22, textAlign: 'center', position: 'relative', overflow: 'hidden',
        background: 'radial-gradient(120% 80% at 50% -20%, var(--gold-tint), transparent 55%)' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
          <UserAvatar av={av} name={name} size={84} />
        </div>
        <h1 style={{ margin: '0 14px', fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, letterSpacing: '-.5px', lineHeight: 1.1 }}>
          What should your<br/>church call you?</h1>
        <p style={{ margin: '10px 26px 0', fontFamily: 'var(--font-read)', fontSize: 15.5, lineHeight: 1.5, color: 'var(--ink-2)', textWrap: 'pretty' }}>
          Pick a name and a mark. No email, no phone — just how friends recognise you. You can stay anonymous.</p>
      </div>

      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '6px 22px 12px' }}>
        {/* name field */}
        <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '8px 0 8px' }}>DISPLAY NAME</label>
        <input value={name} onChange={e => setName(e.target.value.slice(0, 24))} autoFocus placeholder="e.g. Maria, or leave blank" style={{
          width: '100%', height: 54, border: '1px solid var(--line)', borderRadius: 16, background: 'var(--surface)',
          padding: '0 18px', fontSize: 18, fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--ink)', outline: 'none',
          boxShadow: 'var(--shadow)',
        }} />

        {/* avatar */}
        <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '22px 0 12px' }}>CHOOSE YOUR MARK</label>
        <AvatarPicker value={av} name={name} onChange={setAv} />
      </div>

      {/* actions */}
      <div style={{ padding: '12px 22px 26px', borderTop: '1px solid var(--line-2)', background: 'var(--paper)' }}>
        <button onClick={() => onSave({ name: name.trim(), avatar: av })} style={{
          width: '100%', padding: 16, borderRadius: 16, border: 'none', cursor: 'pointer', marginBottom: 10,
          background: 'var(--clay)', color: '#fff', fontWeight: 700, fontSize: 16, fontFamily: 'var(--font-ui)',
        }}>{name.trim() ? `Continue as ${name.trim()}` : 'Continue'}</button>
        <button onClick={onSkip} style={{
          width: '100%', padding: 12, borderRadius: 14, border: 'none', background: 'none', cursor: 'pointer',
          color: 'var(--ink-2)', fontWeight: 600, fontSize: 14.5, fontFamily: 'var(--font-ui)',
        }}>Stay anonymous for now</button>
      </div>
    </div>
  );
}
window.IdentityOnboarding = IdentityOnboarding;

// ════════ Profile sheet (reorganised) ════════
function ProfileSheet({ open, onClose, identity, onSave, ctx }) {
  const D = window.LumenData;
  const [edit, setEdit] = useId(false);
  const [name, setName] = useId(identity.name || '');
  const [av, setAv] = useId(identity.avatar);
  useIdE(() => { if (open) { setEdit(false); setName(identity.name || ''); setAv(identity.avatar); } }, [open, identity]);

  const named = !!(identity.name && identity.name.trim());

  // ── edit mode ──
  if (edit) {
    return (
      <Overlay open={open} onClose={onClose}>
        <div style={{ paddingTop: 50 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 6px' }}>
            <button onClick={() => setEdit(false)} style={{ border: 'none', background: 'none', color: 'var(--ink-2)', fontWeight: 600, fontSize: 15, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Cancel</button>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>Edit profile</span>
            <button onClick={() => { onSave({ name: name.trim(), avatar: av }); setEdit(false); ctx.toast('Profile saved'); }} style={{
              border: 'none', background: 'var(--clay)', color: '#fff', padding: '9px 16px', borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Save</button>
          </div>
        </div>
        <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '14px 22px 30px' }}>
          <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '0 0 8px' }}>DISPLAY NAME</label>
          <input value={name} onChange={e => setName(e.target.value.slice(0, 24))} placeholder="Leave blank to stay anonymous" style={{
            width: '100%', height: 52, border: '1px solid var(--line)', borderRadius: 16, background: 'var(--surface)',
            padding: '0 16px', fontSize: 17, fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--ink)', outline: 'none', boxShadow: 'var(--shadow)' }} />
          <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '22px 0 12px' }}>YOUR MARK</label>
          <AvatarPicker value={av} name={name} onChange={setAv} />
        </div>
      </Overlay>
    );
  }

  // ── view mode ──
  const Group = ({ children }) => (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 18, overflow: 'hidden', boxShadow: 'var(--shadow)', marginBottom: 14 }}>{children}</div>
  );
  const Row = ({ icon, label, sub, onClick, danger, accent }) => (
    <button onClick={onClick} style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', border: 'none',
      borderTop: '1px solid var(--line-2)', background: 'none', cursor: 'pointer', textAlign: 'left',
      color: danger ? 'var(--clay-ink)' : 'var(--ink)', fontFamily: 'var(--font-ui)',
    }}>
      <div style={{ width: 36, height: 36, borderRadius: 11, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: danger ? 'var(--clay-soft)' : 'var(--surface-2)', color: danger ? 'var(--clay-ink)' : (accent || 'var(--ink-2)') }}>
        <Icon name={icon} size={19} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 14.5 }}>{label}</div>
        {sub ? <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</div> : null}
      </div>
      <Icon name="chevR" size={17} color="var(--ink-3)" />
    </button>
  );

  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 6px' }}>
          <IconBtn name="chevD" onClick={onClose} />
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>You</span>
          <IconBtn name="pen" onClick={() => setEdit(true)} />
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '8px 18px 30px' }}>
        {/* identity hero */}
        <div style={{ textAlign: 'center', padding: '14px 0 22px' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 14 }}>
            <UserAvatar av={identity.avatar} name={identity.name} size={104} />
          </div>
          <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 27, fontWeight: 700, letterSpacing: '-.5px' }}>
            {named ? identity.name : 'Anonymous'}</h1>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: 8, background: 'var(--clay-soft)', color: 'var(--clay-ink)',
            padding: '5px 13px', borderRadius: 999, fontSize: 12.5, fontWeight: 700 }}>
            <Icon name="shield" size={13} /> {named ? 'TrinityOne member' : 'Anonymous member'}</div>
          {!named ? (
            <div style={{ marginTop: 16 }}>
              <button onClick={() => setEdit(true)} style={{ border: 'none', background: 'var(--clay)', color: '#fff', padding: '12px 22px',
                borderRadius: 14, fontWeight: 700, fontSize: 15, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Add a name</button>
              <p style={{ fontSize: 12.5, color: 'var(--ink-3)', margin: '12px 22px 0', lineHeight: 1.5 }}>Optional. A name helps your church recognise you — you’ll still share no personal data.</p>
            </div>
          ) : (
            <button onClick={() => setEdit(true)} style={{ marginTop: 14, border: '1px solid var(--line)', background: 'var(--surface)', color: 'var(--ink)',
              padding: '10px 20px', borderRadius: 13, fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'var(--font-ui)', boxShadow: 'var(--shadow)' }}>Edit name & mark</button>
          )}
        </div>

        {/* privacy reassurance */}
        <div style={{ display: 'flex', gap: 11, padding: 14, borderRadius: 16, background: 'color-mix(in oklab, var(--sage) 12%, var(--surface))',
          border: '1px solid color-mix(in oklab, var(--sage) 30%, transparent)', marginBottom: 18 }}>
          <Icon name="shield" size={20} color="var(--sage)" style={{ flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5 }}>
            <b style={{ color: 'var(--ink)' }}>No account, no tracking.</b> Your identity lives only on this device as a private key.</div>
        </div>

        {/* help & guides */}
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.6px', margin: '4px 4px 9px' }}>HELP &amp; SETUP</div>
        <Group>
          <Row icon="book" label="Help & guides" sub="Simple guides, read aloud if you like" accent="var(--clay)" onClick={() => ctx.openHelp('index')} />
          <Row icon="shield" label="Back up your 12 words" sub="The one thing that keeps your account safe" accent="var(--sage)" onClick={() => ctx.openHelp('backup')} />
        </Group>

        {/* security / recovery group */}
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.6px', margin: '16px 4px 9px' }}>SECURITY &amp; RECOVERY</div>
        <Group>
          <Row icon="key" label="Public key" sub={identity.npub.slice(0, 28) + '…'} accent="var(--gold)" onClick={() => ctx.toast('Public key (npub) copied')} />
          <Row icon="shield" label="View recovery phrase" sub="Show the 12 words again" accent="var(--sage)" onClick={() => ctx.openRecovery()} />
          <Row icon="refresh" label="Restore from phrase" onClick={() => ctx.toast('Restore: enter your 12 words')} />
          <Row icon="qr" label="Steward invite" sub="Add someone to your church" accent="var(--clay)" onClick={() => ctx.openInvite()} />
        </Group>

        {/* relays + danger */}
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.6px', margin: '16px 4px 9px' }}>NETWORK</div>
        <Group>
          <Row icon="globe" label="Relays" sub={`${D.RELAYS.filter(r => r.status === 'on').length} connected · Nostr`} onClick={() => ctx.openRelays()} />
        </Group>
        <Group>
          <Row icon="refresh" label="Start a new identity" sub="Replaces this one on this device" danger onClick={() => ctx.toast('This would create a fresh key')} />
        </Group>
      </div>
    </Overlay>
  );
}
window.ProfileSheet = ProfileSheet;
