// app.jsx — Lumen root: nav, theme, shared state, overlays, tweaks
const { useState: useA, useEffect: useAE, useRef: useAR } = React;

const ACCENTS = {
  clay:   { light: { c: '#C25A38', i: '#A8462A', s: '#F3DECF', d: '#9C4327' }, dark: { c: '#E68A66', i: '#EE9E7E', s: '#43271B', d: '#C2613B' } },
  indigo: { light: { c: '#5360D6', i: '#3E49B8', s: '#E2E3F7', d: '#3A43A0' }, dark: { c: '#8E97EE', i: '#A6ADF2', s: '#262A52', d: '#5A63C0' } },
  teal:   { light: { c: '#1F9488', i: '#147A70', s: '#D2EEEA', d: '#136B62' }, dark: { c: '#52C2B4', i: '#6FD0C3', s: '#16403B', d: '#2E9488' } },
  berry:  { light: { c: '#C24B7A', i: '#A53A65', s: '#F6D8E4', d: '#9C3A60' }, dark: { c: '#E681A8', i: '#EE9BBC', s: '#4A2333', d: '#C25C84' } },
};
const READ_FONTS = {
  Newsreader: "'Newsreader', Georgia, serif",
  Lora: "'Newsreader', Georgia, serif",
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": false,
  "accent": "clay",
  "readScale": 1
}/*EDITMODE-END*/;

// ── share verse card ──
const CARD_STYLES = [
  { id: 'clay', bg: 'linear-gradient(155deg, var(--clay), var(--clay-deep))', fg: '#fff', serif: true },
  { id: 'sage', bg: 'linear-gradient(155deg, #6BA17C, #3C6E57)', fg: '#fff', serif: true },
  { id: 'paper', bg: 'var(--surface)', fg: 'var(--ink)', serif: true, bordered: true },
  { id: 'night', bg: 'linear-gradient(155deg, #2a2218, #16120c)', fg: '#F3ECDC', serif: true },
];
function ShareCard({ verse, open, onClose, ctx }) {
  const [style, setStyle] = useA(0);
  useAE(() => { if (open) setStyle(0); }, [open]);
  if (!verse) return null;
  const s = CARD_STYLES[style];
  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50, display: 'flex', flexDirection: 'column', height: '100%' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px' }}>
          <IconBtn name="chevD" onClick={onClose} />
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>Share verse</span>
          <IconBtn name="share" onClick={() => { onClose(); ctx.toast('Card ready to share'); }} />
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '8px 26px' }}>
          <div style={{
            width: '100%', aspectRatio: '4/5', borderRadius: 26, background: s.bg, color: s.fg,
            border: s.bordered ? '1px solid var(--line)' : 'none', boxShadow: 'var(--shadow-lg)',
            display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 30, position: 'relative', overflow: 'hidden',
            transition: 'background .3s',
          }}>
            <div style={{ position: 'absolute', right: -20, top: -20, opacity: s.bordered ? .06 : .14 }}>
              <Icon name="sparkle" size={130} stroke={1.3} color={s.fg} /></div>
            <Icon name="sparkle" size={26} stroke={1.8} color={s.id === 'clay' ? '#fff' : 'var(--clay)'} />
            <p style={{ fontFamily: s.serif ? 'var(--font-read)' : 'var(--font-ui)', fontSize: 25, lineHeight: 1.4,
              fontWeight: 500, margin: '18px 0 20px', textWrap: 'pretty' }}>“{verse.text}”</p>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 14, letterSpacing: '.5px',
              color: s.bordered ? 'var(--clay)' : s.fg, opacity: s.bordered ? 1 : .9 }}>{verse.ref} · {verse.version || 'WEB'}</div>
            <div style={{ position: 'absolute', bottom: 16, right: 22, fontSize: 11, fontWeight: 700, letterSpacing: '1px', opacity: .5 }}>TRINITYONE</div>
          </div>
        </div>
        <div style={{ padding: '4px 26px 8px' }}>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 18 }}>
            {CARD_STYLES.map((c, i) => (
              <button key={c.id} onClick={() => setStyle(i)} style={{
                width: 46, height: 46, borderRadius: 14, background: c.bg, cursor: 'pointer',
                border: style === i ? '2.5px solid var(--clay)' : '1px solid var(--line)', flexShrink: 0,
              }} />
            ))}
          </div>
          <button onClick={() => { onClose(); ctx.toast('Saved to Photos'); }} style={{
            width: '100%', padding: 15, borderRadius: 16, border: 'none', background: 'var(--clay)', color: '#fff',
            fontWeight: 700, fontSize: 15.5, cursor: 'pointer', fontFamily: 'var(--font-ui)', marginBottom: 14,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}><Icon name="arrowUp" size={18} color="#fff" /> Save image</button>
        </div>
      </div>
    </Overlay>
  );
}

// ── devotional overlay ──
function DevotionalView({ open, onClose, ctx }) {
  const d = window.LumenData.DEVOTIONAL;
  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50, background: 'linear-gradient(160deg, #6BA17C, #3C6E57)', color: '#fff', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', right: -24, top: -10, opacity: .18 }}><Icon name="sun" size={150} stroke={1.3} color="#fff" /></div>
        <div style={{ padding: '10px 18px 24px', position: 'relative' }}>
          <button onClick={onClose} style={{ width: 40, height: 40, borderRadius: 13, border: 'none', background: 'rgba(255,255,255,.2)',
            color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="chevD" size={20} color="#fff" /></button>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '1px', textTransform: 'uppercase', opacity: .9, marginTop: 16 }}>{d.series} · {d.day}</div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 29, fontWeight: 700, margin: '6px 0 8px', lineHeight: 1.08 }}>{d.title}</h1>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'rgba(255,255,255,.2)', padding: '5px 12px', borderRadius: 999, fontSize: 13, fontWeight: 700 }}>
            <Icon name="read" size={15} color="#fff" /> {d.ref} · {d.read}</div>
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '22px 22px 30px' }}>
        {d.body.map((para, i) => (
          <p key={i} style={{ fontFamily: 'var(--font-read)', fontSize: 18.5, lineHeight: 1.66, color: 'var(--ink)', margin: '0 0 16px', textWrap: 'pretty' }}>{para}</p>
        ))}
        <div style={{ background: 'var(--surface-2)', border: '1px solid var(--line)', borderRadius: 20, padding: 20, marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--clay)', fontWeight: 700, fontSize: 13, marginBottom: 8 }}>
            <Icon name="pen" size={16} /> REFLECT</div>
          <p style={{ fontFamily: 'var(--font-read)', fontSize: 18, lineHeight: 1.55, color: 'var(--ink)', margin: '0 0 14px', fontStyle: 'italic' }}>{d.prompt}</p>
          <button onClick={() => { onClose(); ctx.go('library'); ctx.toast('Opening journal'); }} style={{
            border: 'none', background: 'var(--clay)', color: '#fff', padding: '11px 18px', borderRadius: 13,
            fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Write a reflection</button>
        </div>
        <button onClick={() => { onClose(); ctx.toast('Day 4 complete · streak 13'); }} style={{
          width: '100%', marginTop: 16, padding: 15, borderRadius: 16, border: '1.5px solid var(--clay)', background: 'transparent',
          color: 'var(--clay)', fontWeight: 700, fontSize: 15, cursor: 'pointer', fontFamily: 'var(--font-ui)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <Icon name="check" size={18} stroke={2.4} /> Mark complete</button>
      </div>
    </Overlay>
  );
}

function Splash({ onDone }) {
  useAE(() => { const t = setTimeout(onDone, 2350); return () => clearTimeout(t); }, []);
  return (
    <div className="to-splash">
      <svg className="sp-mark" viewBox="0 0 100 100" aria-label="TrinityOne">
        <path className="sp-arc a1" d="M81.2 67.9 A36 36 0 0 1 31.3 80.7" />
        <path className="sp-arc a2" d="M18.8 68.0 A36 36 0 0 1 32.7 18.4" />
        <path className="sp-arc a3" d="M49.9 14.0 A36 36 0 0 1 86.0 50.8" />
        <circle className="sp-spark" cx="50" cy="50" r="6.5" />
      </svg>
      <div className="sp-wm">Trinity<span className="one">One</span></div>
      <div className="sp-tag">Read · Gather · Share</div>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = useA('today');
  const [toastMsg, setToastMsg] = useA('');
  const toastTimer = useAR();

  // shared study state
  const [highlights, setHighlights] = useA({ 4: 'var(--hl-yellow)' });
  const [notes, setNotes] = useA({ 4: 'Life and light keep showing up together in John.' });
  const [bookmarks, setBookmarks] = useA([1]);

  // overlays
  const [share, setShare] = useA(null);
  const [devo, setDevo] = useA(false);
  const [plan, setPlan] = useA(null);
  const [journal, setJournal] = useA(null);
  const [wordOv, setWordOv] = useA(null);
  const [video, setVideo] = useA(null);
  const [group, setGroup] = useA(null);
  const [showSplash, setShowSplash] = useA(true);
  const [walletSats, setWalletSats] = useA(window.LumenData.WALLET.sats);
  const [giving, setGiving] = useA(window.LumenData.GIVING_HISTORY);

  // ── identity ──
  const [identity, setIdentityState] = useA(() => {
    try { const s = JSON.parse(localStorage.getItem('to_identity')); if (s) return s; } catch (e) {}
    return window.LumenData.MY_IDENTITY;
  });
  const [onboard, setOnboard] = useA(() => {
    try { return localStorage.getItem('to_onboarded') !== '1'; } catch (e) { return true; }
  });
  const [profile, setProfile] = useA(false);
  const [member, setMember] = useA(null);
  const [idSheet, setIdSheet] = useA(null); // 'recovery'|'invite'|'relays'
  const [help, setHelp] = useA(null); // null | 'index' | articleId | 'backup'
  const [backupNudge, setBackupNudge] = useA(false);
  const saveIdentity = (patch) => setIdentityState(prev => {
    const next = { ...prev, ...patch };
    try { localStorage.setItem('to_identity', JSON.stringify(next)); } catch (e) {}
    return next;
  });
  const finishOnboard = () => { try { localStorage.setItem('to_onboarded', '1'); } catch (e) {} setOnboard(false); };

  // scaling to viewport
  const wrapRef = useAR();
  useAE(() => {
    const fit = () => {
      const W = 392, H = 846, m = 24;
      const sc = Math.min(1, (window.innerWidth - m) / W, (window.innerHeight - m) / H);
      if (wrapRef.current) wrapRef.current.style.transform = `scale(${sc})`;
    };
    fit(); window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  const toast = (msg) => {
    setToastMsg(msg); clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(''), 1900);
  };

  const ctx = {
    dark: t.dark,
    toggleDark: () => setTweak('dark', !t.dark),
    go: setTab, toast,
    openReader: () => setTab('read'),
    openShare: (v) => setShare(v),
    openDevotional: () => setDevo(true),
    openPlan: (p) => setPlan(p),
    openJournal: (j) => setJournal(j),
    openVideo: (v) => setVideo(v),
    openGroup: (g) => setGroup(g),
    walletSats, setWalletSats, giving, setGiving,
    identity,
    openProfile: () => setProfile(true),
    openMember: (name) => { const m = window.LumenData.MEMBERS[name]; if (m) setMember(m); },
    openRecovery: () => setIdSheet('recovery'),
    openInvite: () => setIdSheet('invite'),
    openRelays: () => setIdSheet('relays'),
    openHelp: (v) => setHelp(v || 'index'),
    openWord: (id) => setWordOv(id),
    readScale: t.readScale,
    highlights, setHighlight: (v, c) => setHighlights(h => { const n = { ...h }; if (c) n[v] = c; else delete n[v]; return n; }),
    notes, setNote: (v, txt) => setNotes(n => ({ ...n, [v]: txt })),
    bookmarks, toggleBookmark: (v) => setBookmarks(b => b.includes(v) ? b.filter(x => x !== v) : [...b, v]),
  };

  // apply accent vars
  const acc = ACCENTS[t.accent] || ACCENTS.clay;
  const ap = t.dark ? acc.dark : acc.light;
  const rootStyle = {
    '--clay': ap.c, '--clay-ink': ap.i, '--clay-soft': ap.s, '--clay-deep': ap.d,
    '--read-scale': t.readScale,
  };

  const screens = {
    today: <TodayScreen ctx={ctx} />,
    read: <ReadScreen ctx={ctx} />,
    plans: <PlansScreen ctx={ctx} />,
    chat: <ChatScreen ctx={ctx} />,
    library: <LibraryScreen ctx={ctx} />,
    search: <SearchScreen ctx={ctx} />,
  };

  return (
    <div ref={wrapRef} className={cx('lumen', t.dark && 'dark')} style={{ ...rootStyle, transformOrigin: 'center center' }}>
      <PhoneFrame>
        <div style={{ position: 'absolute', inset: 0 }}>{screens[tab]}</div>
        <TabBar active={tab} onChange={setTab} />

        {/* overlays */}
        <ShareCard verse={share} open={!!share} onClose={() => setShare(null)} ctx={ctx} />
        <DevotionalView open={devo} onClose={() => setDevo(false)} ctx={ctx} />
        <PlanDetail plan={plan} open={!!plan} onClose={() => setPlan(null)} ctx={ctx} />
        <JournalView entry={journal} open={!!journal} onClose={() => setJournal(null)} />
        <VideoPlayer video={video} open={!!video} onClose={() => setVideo(null)} ctx={ctx} />
        <ChatRoom group={group} open={!!group} onClose={() => setGroup(null)} ctx={ctx} />
        <WordStudySheet id={wordOv} open={!!wordOv} onClose={() => setWordOv(null)} />

        {/* identity */}
        <ProfileSheet open={profile} onClose={() => setProfile(false)} identity={identity} onSave={saveIdentity} ctx={ctx} />
        <MemberCard member={member} open={!!member} onClose={() => setMember(null)} ctx={ctx} />
        <RecoverySheet open={idSheet === 'recovery'} onClose={() => setIdSheet(null)} ctx={ctx} />
        <InviteSheet open={idSheet === 'invite'} onClose={() => setIdSheet(null)} identity={identity} ctx={ctx} />
        <RelaysSheet open={idSheet === 'relays'} onClose={() => setIdSheet(null)} ctx={ctx} />
        <HelpCenter open={!!help} initial={help} onClose={() => setHelp(null)} ctx={ctx} />
        <BackupNudge open={backupNudge} onClose={() => setBackupNudge(false)}
          onBackup={() => { setBackupNudge(false); setHelp('backup'); }} />
        <IdentityOnboarding open={onboard && !showSplash} identity={identity}
          onSave={(patch) => { saveIdentity(patch); finishOnboard(); setBackupNudge(true); }} onSkip={() => { finishOnboard(); setBackupNudge(true); }} />

        <Toast msg={toastMsg} />
        {showSplash ? <Splash onDone={() => setShowSplash(false)} /> : null}
      </PhoneFrame>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakToggle label="Dark mode" value={t.dark} onChange={(v) => setTweak('dark', v)} />
        <TweakColor label="Accent" value={t.accent === 'clay' ? '#C25A38' : t.accent === 'indigo' ? '#5360D6' : t.accent === 'teal' ? '#1F9488' : '#C24B7A'}
          options={['#C25A38', '#5360D6', '#1F9488', '#C24B7A']}
          onChange={(v) => setTweak('accent', { '#C25A38': 'clay', '#5360D6': 'indigo', '#1F9488': 'teal', '#C24B7A': 'berry' }[v])} />
        <TweakSection label="Reading" />
        <TweakSlider label="Scripture size" value={t.readScale} min={0.9} max={1.3} step={0.05} onChange={(v) => setTweak('readScale', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
