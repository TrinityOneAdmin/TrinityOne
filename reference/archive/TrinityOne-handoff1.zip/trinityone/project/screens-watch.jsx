// screens-watch.jsx — "Watch" tab: church videos via YouTube
const { useState: useW } = React;

function parseYT(url) {
  if (!url) return null;
  const m = String(url).match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{11}$/.test(url.trim())) return url.trim();
  return null;
}

// gradient poster (no broken thumbnails — curated placeholder art)
function VideoPoster({ v, h = 200, rounded = 20 }) {
  return (
    <div style={{
      position: 'relative', height: h, borderRadius: rounded, overflow: 'hidden',
      background: `linear-gradient(150deg, ${v.accent}, color-mix(in oklab, ${v.accent} 55%, #16120c))`,
    }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 78% 18%, rgba(255,255,255,.28), transparent 50%)' }} />
      <div style={{ position: 'absolute', right: -22, bottom: -26, opacity: .16 }}><Icon name={v.icon || 'play'} size={Math.round(h*0.9)} stroke={1.2} color="#fff" /></div>
      {/* play button */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: 54, height: 54, borderRadius: 999, background: 'rgba(255,255,255,.92)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 6px 20px rgba(0,0,0,.3)' }}>
          <Icon name="play" size={22} color="var(--clay-ink)" />
        </div>
      </div>
      {v.live ? <span style={{ position: 'absolute', top: 12, left: 12, display: 'flex', alignItems: 'center', gap: 5,
        background: '#e0322f', color: '#fff', padding: '4px 9px', borderRadius: 7, fontSize: 11, fontWeight: 800, letterSpacing: '.5px' }}>
        <span style={{ width: 6, height: 6, borderRadius: 999, background: '#fff' }} />LIVE</span> : null}
      <span style={{ position: 'absolute', bottom: 10, right: 10, background: 'rgba(0,0,0,.7)', color: '#fff',
        padding: '3px 8px', borderRadius: 7, fontSize: 11.5, fontWeight: 700 }}>{v.dur}</span>
    </div>
  );
}

function VideoRow({ v, onClick }) {
  return (
    <div onClick={onClick} style={{ display: 'flex', gap: 12, cursor: 'pointer' }}>
      <div style={{ width: 150, flexShrink: 0 }}><VideoPoster v={v} h={86} rounded={14} /></div>
      <div style={{ flex: 1, minWidth: 0, paddingTop: 2 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14.5, lineHeight: 1.22,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{v.title}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)', fontWeight: 600, marginTop: 4 }}>{v.channel}</div>
        <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 1 }}>{v.views} views · {v.when}</div>
      </div>
    </div>
  );
}

function WatchView({ ctx }) {
  const D = window.LumenData;
  const [cat, setCat] = useW('All');
  const [paste, setPaste] = useW('');
  const list = cat === 'All' ? D.VIDEOS : D.VIDEOS.filter(v => v.cat === cat);
  const featured = D.VIDEOS[0];

  const add = () => {
    const id = parseYT(paste);
    if (!id) { ctx.toast('Paste a valid YouTube link'); return; }
    ctx.openVideo({ id: 'paste-' + id, title: 'Your video', channel: 'From YouTube', dur: '', when: 'just now',
      views: '—', accent: 'var(--clay)', icon: 'play', ytId: id, desc: 'Added from a YouTube link.' });
    setPaste('');
  };

  return (
    <div style={{ animation: 'lumenFade .4s ease both' }}>
      {/* featured */}
      <div onClick={() => ctx.openVideo(featured)} style={{ cursor: 'pointer', marginBottom: 8 }}>
        <VideoPoster v={featured} h={196} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginTop: 11 }}>
          <div style={{ width: 34, height: 34, borderRadius: 999, background: featured.accent, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontFamily: 'var(--font-display)', fontSize: 15 }}>G</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, lineHeight: 1.2 }}>{featured.title}</div>
            <div style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{featured.channel} · {featured.views} watching</div>
          </div>
        </div>
      </div>

      {/* category chips */}
      <div className="no-scrollbar" style={{ display: 'flex', gap: 8, overflowX: 'auto', margin: '18px -18px 18px', padding: '0 18px' }}>
        {D.VIDEO_CATS.map(c => <Chip key={c} active={cat === c} onClick={() => setCat(c)}>{c}</Chip>)}
      </div>

      {/* channels you follow */}
      {cat === 'All' ? (
        <div style={{ marginBottom: 22 }}>
          <SectionLabel>Churches you follow</SectionLabel>
          <div className="no-scrollbar" style={{ display: 'flex', gap: 14, overflowX: 'auto', margin: '0 -18px', padding: '0 18px 4px' }}>
            {D.CHANNELS.map(ch => (
              <button key={ch.id} onClick={() => ctx.toast('Opening ' + ch.name)} style={{
                border: 'none', background: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column',
                alignItems: 'center', gap: 7, flexShrink: 0, width: 74 }}>
                <div style={{ width: 62, height: 62, borderRadius: 999, background: `linear-gradient(150deg, ${ch.accent}, color-mix(in oklab, ${ch.accent} 55%, #16120c))`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 24, fontFamily: 'var(--font-display)' }}>{ch.name[0]}</div>
                <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--ink-2)', textAlign: 'center', lineHeight: 1.15 }}>{ch.name}</span>
              </button>
            ))}
            <button onClick={() => ctx.toast('Find churches')} style={{ border: 'none', background: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7, flexShrink: 0, width: 74 }}>
              <div style={{ width: 62, height: 62, borderRadius: 999, border: '1.5px dashed var(--ink-3)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-3)' }}><Icon name="plus" size={24} /></div>
              <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--ink-2)' }}>Find more</span>
            </button>
          </div>
        </div>
      ) : null}

      {/* list */}
      <SectionLabel>{cat === 'All' ? 'Latest' : cat}</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {list.map(v => <VideoRow key={v.id} v={v} onClick={() => ctx.openVideo(v)} />)}
      </div>

      {/* paste a link */}
      <div style={{ marginTop: 24, padding: 16, borderRadius: 20, background: 'var(--surface-2)', border: '1px dashed color-mix(in oklab, var(--clay) 40%, var(--line))' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Icon name="plus" size={17} color="var(--clay)" stroke={2.4} />
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>Loop in a video</span>
        </div>
        <p style={{ margin: '0 0 12px', fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.4 }}>Paste any YouTube link from your church and it plays right here.</p>
        <div style={{ display: 'flex', gap: 9 }}>
          <input value={paste} onChange={e => setPaste(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') add(); }}
            placeholder="youtube.com/watch?v=…" style={{ flex: 1, minWidth: 0, height: 44, padding: '0 14px', borderRadius: 13,
            border: '1px solid var(--line)', background: 'var(--surface)', outline: 'none', fontSize: 14, color: 'var(--ink)', fontFamily: 'var(--font-ui)' }} />
          <button onClick={add} style={{ border: 'none', background: 'var(--clay)', color: '#fff', padding: '0 18px', borderRadius: 13,
            fontWeight: 700, fontSize: 14.5, cursor: 'pointer', fontFamily: 'var(--font-ui)', flexShrink: 0 }}>Add</button>
        </div>
      </div>
    </div>
  );
}

// ── player overlay ──
function VideoPlayer({ video, open, onClose, ctx }) {
  const [liveId, setLiveId] = useW(null);
  const [paste, setPaste] = useW('');
  React.useEffect(() => { if (open) { setLiveId(video && video.ytId ? video.ytId : null); setPaste(''); } }, [open, video]);
  if (!video) return null;
  const D = window.LumenData;
  const more = D.VIDEOS.filter(v => v.id !== video.id).slice(0, 3);

  const tryPlay = () => {
    const id = parseYT(paste);
    if (!id) { ctx.toast('Paste a valid YouTube link'); return; }
    setLiveId(id);
  };

  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 14px 8px' }}>
          <IconBtn name="chevD" onClick={onClose} />
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>Watch</span>
          <IconBtn name="share" onClick={() => ctx.toast('Link copied')} />
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', paddingBottom: 30 }}>
        {/* video frame */}
        <div style={{ margin: '0 14px', borderRadius: 18, overflow: 'hidden', background: '#000', aspectRatio: '16/9', position: 'relative' }}>
          {liveId ? (
            <iframe title="video" width="100%" height="100%" style={{ border: 'none', display: 'block' }}
              src={`https://www.youtube-nocookie.com/embed/${liveId}?autoplay=1&rel=0&modestbranding=1`}
              allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen />
          ) : (
            <div style={{ position: 'absolute', inset: 0 }}>
              <VideoPoster v={video} h={9999} rounded={0} />
              <div onClick={() => { const inp = document.getElementById('lumen-paste'); inp && inp.focus(); }}
                style={{ position: 'absolute', inset: 0 }} />
            </div>
          )}
        </div>

        <div style={{ padding: '14px 18px 0' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, margin: 0, lineHeight: 1.18 }}>{video.title}</h1>
          <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 5 }}>{video.views} views · {video.when}</div>

          {/* paste-to-play (when not yet playing) */}
          {!liveId ? (
            <div style={{ marginTop: 14, padding: 14, borderRadius: 16, background: 'var(--clay-soft)', border: '1px solid color-mix(in oklab, var(--clay) 25%, transparent)' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--clay-ink)', marginBottom: 9 }}>Paste this church’s YouTube link to play it in TrinityOne</div>
              <div style={{ display: 'flex', gap: 9 }}>
                <input id="lumen-paste" value={paste} onChange={e => setPaste(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') tryPlay(); }}
                  placeholder="youtu.be/…" style={{ flex: 1, minWidth: 0, height: 42, padding: '0 13px', borderRadius: 12, border: '1px solid var(--line)',
                  background: 'var(--surface)', outline: 'none', fontSize: 14, color: 'var(--ink)', fontFamily: 'var(--font-ui)' }} />
                <button onClick={tryPlay} style={{ border: 'none', background: 'var(--clay)', color: '#fff', padding: '0 16px', borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: 'pointer', flexShrink: 0 }}>Play</button>
              </div>
              <button onClick={() => setLiveId('jNQXAC9IVRw')} style={{ marginTop: 10, border: 'none', background: 'none', color: 'var(--clay-ink)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer', textDecoration: 'underline', padding: 0 }}>Load a sample clip to test the player →</button>
            </div>
          ) : null}

          {/* channel row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, margin: '16px 0', paddingBottom: 16, borderBottom: '1px solid var(--line)' }}>
            <div style={{ width: 42, height: 42, borderRadius: 999, background: video.accent, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontFamily: 'var(--font-display)', fontSize: 18 }}>{video.channel[0]}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5 }}>{video.channel}</div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>Church · YouTube</div>
            </div>
            <button onClick={() => ctx.toast('Following ' + video.channel)} style={{ border: 'none', background: 'var(--ink)', color: 'var(--paper)', padding: '9px 16px', borderRadius: 999, fontWeight: 700, fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Follow</button>
          </div>

          <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, lineHeight: 1.6, color: 'var(--ink)', margin: '0 0 22px', textWrap: 'pretty' }}>{video.desc}</p>

          <SectionLabel>Up next</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {more.map(v => <VideoRow key={v.id} v={v} onClick={() => { setLiveId(v.ytId || null); setPaste(''); ctx.openVideo(v); }} />)}
          </div>
        </div>
      </div>
    </Overlay>
  );
}

Object.assign(window, { WatchView, VideoPlayer, parseYT });
