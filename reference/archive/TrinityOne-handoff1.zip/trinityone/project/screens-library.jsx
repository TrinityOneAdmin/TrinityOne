// screens-library.jsx — modules home (Bibles, Commentaries, Dictionaries, Devotionals, Books, Journals) + collections + journal
function ModuleTile({ m, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 13, padding: 14, borderRadius: 18,
      background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)',
    }}>
      <div style={{ width: 44, height: 44, borderRadius: 13, flexShrink: 0,
        background: `color-mix(in oklab, ${m.accent} 16%, var(--surface))`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: m.accent }}>
        <Icon name={m.icon} size={23} stroke={1.8} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15.5 }}>{m.name}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{m.count}</div>
      </div>
      <Icon name="chevR" size={18} color="var(--ink-3)" />
    </div>
  );
}

function LibraryScreen({ ctx }) {
  const D = window.LumenData;
  const [view, setView] = React.useState('library');
  return (
    <ScreenScroll>
      <h1 style={{ margin: '0 0 14px', fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, letterSpacing: '-.5px', animation: 'lumenFade .5s ease both' }}>Library</h1>

      {/* segmented: Library / Watch */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 15, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 20 }}>
        {[['library', 'Library', 'library'], ['watch', 'Watch', 'play']].map(([id, label, ic]) => {
          const on = view === id;
          return (
            <button key={id} onClick={() => setView(id)} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, padding: '10px',
              borderRadius: 11, border: 'none', cursor: 'pointer', fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 14,
              background: on ? 'var(--surface)' : 'transparent', color: on ? 'var(--clay)' : 'var(--ink-2)',
              boxShadow: on ? 'var(--shadow)' : 'none', transition: 'all .2s',
            }}><Icon name={ic} size={17} stroke={on ? 2.1 : 1.8} />{label}</button>
          );
        })}
      </div>

      {view === 'watch' ? <WatchView ctx={ctx} /> : <LibraryHome ctx={ctx} />}
    </ScreenScroll>
  );
}

function LibraryHome({ ctx }) {
  const D = window.LumenData;
  return (
    <React.Fragment>
      {/* collections strip */}
      <div className="no-scrollbar" style={{ display: 'flex', gap: 10, overflowX: 'auto', margin: '0 -18px 22px', padding: '0 18px', animation: 'lumenFade .5s ease .05s both' }}>
        {D.COLLECTIONS.map(c => (
          <button key={c.id} onClick={() => ctx.toast(`${c.name}: ${c.count}`)} style={{
            flexShrink: 0, width: 110, padding: '14px 14px', borderRadius: 18, border: '1px solid var(--line)',
            background: 'var(--surface)', cursor: 'pointer', textAlign: 'left', color: 'var(--ink)', boxShadow: 'var(--shadow)',
          }}>
            <Icon name={c.icon} size={22} color="var(--clay)" />
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, marginTop: 8, lineHeight: 1 }}>{c.count}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-2)', fontWeight: 600, marginTop: 2 }}>{c.name}</div>
          </button>
        ))}
      </div>

      <SectionLabel>Modules</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginBottom: 24, animation: 'lumenFade .5s ease .1s both' }}>
        {D.MODULES.map(m => <ModuleTile key={m.id} m={m} onClick={() => ctx.toast(`Opening ${m.name}`)} />)}
      </div>

      <SectionLabel action="New" onAction={() => ctx.toast('New journal entry')}>Recent journal</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11, animation: 'lumenFade .5s ease .15s both' }}>
        {D.JOURNAL.map(j => (
          <div key={j.id} onClick={() => ctx.openJournal(j)} style={{
            padding: 15, borderRadius: 18, background: 'var(--surface)', border: '1px solid var(--line)',
            cursor: 'pointer', position: 'relative', overflow: 'hidden', boxShadow: 'var(--shadow)',
          }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 5, background: j.color }} />
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--clay)' }}>{j.ref}</span>
              <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>{j.date}</span>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, marginBottom: 3 }}>{j.title}</div>
            <p style={{ margin: 0, fontFamily: 'var(--font-read)', fontSize: 15, lineHeight: 1.5, color: 'var(--ink-2)',
              display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{j.body}</p>
          </div>
        ))}
      </div>
    </React.Fragment>
  );
}

// ── journal entry overlay ──
function JournalView({ entry, open, onClose }) {
  if (!entry) return null;
  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 6px' }}>
          <IconBtn name="chevD" onClick={onClose} />
          <IconBtn name="pen" onClick={() => {}} />
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '12px 22px 30px' }}>
        <span style={{ display: 'inline-block', background: entry.color, color: 'var(--ink)', padding: '5px 12px',
          borderRadius: 999, fontSize: 12.5, fontWeight: 700, marginBottom: 14 }}>{entry.ref}</span>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, margin: '0 0 6px', lineHeight: 1.1 }}>{entry.title}</h1>
        <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 22 }}>{entry.date}</div>
        <p style={{ fontFamily: 'var(--font-read)', fontSize: 19, lineHeight: 1.65, color: 'var(--ink)', textWrap: 'pretty' }}>{entry.body}</p>
      </div>
    </Overlay>
  );
}

Object.assign(window, { LibraryScreen, JournalView });
