// screens-search.jsx — universal search across scripture + lexicon
const { useState: useSrch } = React;

function SearchScreen({ ctx }) {
  const D = window.LumenData;
  const [q, setQ] = useSrch('');
  const [active, setActive] = useSrch('');
  const run = (term) => { setQ(term); setActive(term.toLowerCase()); };
  const res = D.SEARCH_RESULTS[active];

  return (
    <ScreenScroll top={56}>
      <h1 style={{ margin: '0 0 14px', fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, letterSpacing: '-.5px' }}>Search</h1>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 15px', height: 50, borderRadius: 16,
        background: 'var(--surface)', border: '1px solid var(--line)', boxShadow: 'var(--shadow)', marginBottom: 18 }}>
        <Icon name="study" size={20} color="var(--ink-3)" />
        <input value={q} onChange={e => setQ(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') run(q); }}
          placeholder="Search scripture, words, notes…" style={{
            flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 16,
            fontFamily: 'var(--font-ui)', color: 'var(--ink)',
          }} />
        {q ? <button onClick={() => { setQ(''); setActive(''); }} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink-3)', display: 'flex' }}><Icon name="x" size={18} /></button> : null}
      </div>

      {!res ? (
        <div style={{ animation: 'lumenFade .4s ease both' }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>TRY SEARCHING</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, marginBottom: 28 }}>
            {D.SEARCH_SEED.map(s => <Chip key={s} onClick={() => run(s)}>{s}</Chip>)}
          </div>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>SEARCH ACROSS</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {[['read', 'All Bibles', '12 translations'], ['lex', 'Lexicons', 'Greek & Hebrew'], ['comment', 'Commentaries', '8 sets'], ['pen', 'Your notes', '23 entries']].map(([ic, t, s]) => (
              <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: 13, borderRadius: 16,
                background: 'var(--surface-2)', border: '1px solid var(--line)' }}>
                <Icon name={ic} size={20} color="var(--clay)" />
                <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14.5 }}>{t}</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>{s}</div></div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{ animation: 'lumenFade .4s ease both' }}>
          <div style={{ fontSize: 13.5, color: 'var(--ink-2)', marginBottom: 18 }}>
            <b style={{ color: 'var(--ink)' }}>{res.count}</b> results for “<b style={{ color: 'var(--clay)' }}>{active}</b>”
          </div>

          {/* lexicon hit */}
          {res.lexicon.map(id => {
            const e = D.LEXICON[id];
            return (
              <div key={id} onClick={() => ctx.openWord(id)} style={{
                borderRadius: 18, padding: 16, marginBottom: 18, cursor: 'pointer',
                background: 'var(--clay-soft)', border: '1px solid color-mix(in oklab, var(--clay) 25%, transparent)' }}>
                <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--clay-ink)', letterSpacing: '.5px' }}>LEXICON · STRONG'S {id}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
                  <span style={{ fontFamily: 'var(--font-read)', fontSize: 26, fontWeight: 500, color: 'var(--ink)' }}>{e.lemma}</span>
                  <span style={{ fontFamily: 'var(--font-read)', fontStyle: 'italic', color: 'var(--ink-2)' }}>{e.translit}</span>
                </div>
                <div style={{ fontSize: 14, color: 'var(--ink)', marginTop: 4, fontWeight: 500 }}>{e.short}</div>
              </div>
            );
          })}

          <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>IN SCRIPTURE</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {res.scripture.map((r, i) => (
              <div key={i} onClick={() => ctx.openReader()} style={{
                padding: 15, borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)' }}>
                <div style={{ fontWeight: 700, color: 'var(--clay)', fontSize: 13.5, marginBottom: 4 }}>{r.ref}</div>
                <p style={{ margin: 0, fontFamily: 'var(--font-read)', fontSize: 16.5, lineHeight: 1.5, color: 'var(--ink)', textWrap: 'pretty' }}
                  dangerouslySetInnerHTML={{ __html: r.text.replace(new RegExp(`(${active})`, 'gi'), '<mark style="background:var(--hl-yellow);color:inherit;border-radius:3px;padding:0 2px;">$1</mark>') }} />
              </div>
            ))}
          </div>
        </div>
      )}
    </ScreenScroll>
  );
}

window.SearchScreen = SearchScreen;
