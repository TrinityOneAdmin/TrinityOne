// screens-chat.jsx — "Chat" tab: anonymous church + life-group messaging over Nostr
const { useState: useC, useEffect: useCE, useRef: useCR } = React;

// avatar = colored circle with the descriptive word's initial
function Avatar({ handle, color, size = 38 }) {
  const word = (handle || 'Anonymous').split(' ').slice(-1)[0];
  return (
    <div style={{
      width: size, height: size, borderRadius: 999, flexShrink: 0,
      background: `linear-gradient(150deg, ${color}, color-mix(in oklab, ${color} 60%, #16120c))`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}><Halo size={size * 0.62} color="#fff" open={true} /></div>
  );
}

// ── Nostr explainer sheet ──
function NostrSheet({ open, onClose, ctx }) {
  const id = window.LumenData.CHAT_IDENTITY;
  const relays = window.LumenData.RELAYS;
  return (
    <BottomSheet open={open} onClose={onClose} maxHeight="84%">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 38, height: 38, borderRadius: 12, background: 'var(--clay-soft)', color: 'var(--clay-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="shield" size={21} /></div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>You’re anonymous</div>
        </div>
        <IconBtn name="x" onClick={onClose} />
      </div>
      <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, lineHeight: 1.55, color: 'var(--ink-2)', margin: '8px 0 18px', textWrap: 'pretty' }}>
        Chat runs on <b style={{ color: 'var(--ink)' }}>Nostr</b>, an open protocol. There’s no email, no phone number, no account — just a key that lives on your device. Your church sees a friendly handle, never you.
      </p>

      {/* identity card */}
      <div style={{ borderRadius: 18, padding: 16, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Avatar handle={id.handle} color={id.color} size={48} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>{id.handle}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--ink-3)', fontSize: 12, fontFamily: 'var(--font-ui)' }}>
              <Icon name="key" size={13} /><span style={{ fontFamily: 'monospace', letterSpacing: '-.3px' }}>{id.npub.slice(0, 20)}…</span>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9, marginTop: 14 }}>
          <button onClick={() => ctx.toast('Public key copied')} style={miniBtn()}>
            <Icon name="copy" size={15} /> Copy npub</button>
          <button onClick={() => ctx.toast('New anonymous identity created')} style={miniBtn()}>
            <Icon name="refresh" size={15} /> New identity</button>
        </div>
      </div>

      {/* relays */}
      <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '4px 0 9px' }}>RELAYS</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 8 }}>
        {relays.map(r => (
          <div key={r.url} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 14px', borderRadius: 13, background: 'var(--surface-2)', border: '1px solid var(--line)' }}>
            <Icon name="globe" size={17} color={r.status === 'on' ? 'var(--sage)' : 'var(--ink-3)'} />
            <span style={{ flex: 1, fontFamily: 'monospace', fontSize: 13.5, color: 'var(--ink)' }}>{r.url}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 700, color: r.status === 'on' ? 'var(--sage)' : 'var(--ink-3)' }}>
              <span style={{ width: 7, height: 7, borderRadius: 999, background: r.status === 'on' ? 'var(--sage)' : 'var(--ink-3)' }} />
              {r.status === 'on' ? 'Connected' : 'Off'}
            </span>
          </div>
        ))}
      </div>
    </BottomSheet>
  );
}
function miniBtn() {
  return { flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, padding: '11px',
    borderRadius: 12, border: '1px solid var(--line)', background: 'var(--surface)', cursor: 'pointer',
    color: 'var(--ink)', fontWeight: 700, fontSize: 13, fontFamily: 'var(--font-ui)' };
}

// ── group list (the Chat tab body) ──
// ── create / join a group ──
const GROUP_KINDS = ['Life Group', 'Ministry', 'Whole Church'];
const GROUP_ACCENTS = ['var(--clay)', 'var(--sage)', 'var(--gold)', '#5360D6', '#C24B7A', '#2A8C82'];
function NewGroupSheet({ open, onClose, onCreate, onJoin, ctx }) {
  const [mode, setMode] = useC('create');
  const [name, setName] = useC('');
  const [kind, setKind] = useC('Life Group');
  const [accent, setAccent] = useC('var(--clay)');
  const [prayer, setPrayer] = useC(false);
  const [code, setCode] = useC('');
  useCE(() => { if (open) { setMode('create'); setName(''); setKind('Life Group'); setAccent('var(--clay)'); setPrayer(false); setCode(''); } }, [open]);

  const make = () => {
    const nm = name.trim() || 'New Group';
    onCreate({ id: 'g' + Date.now(), name: nm, kind: prayer ? 'Prayer' : kind, members: 1, accent,
      unread: 0, last: 'You created this group', when: 'now', prayer });
  };
  const join = () => {
    const c = code.trim();
    onJoin({ id: 'join-' + c.toLowerCase().replace(/[^a-z0-9]/g, '') || 'joined', name: c ? `Group · ${c.toUpperCase()}` : 'Joined Group',
      kind: 'Life Group', members: 8, accent: 'var(--sage)', unread: 0, last: 'You joined this group', when: 'now' });
  };

  return (
    <BottomSheet open={open} onClose={onClose} maxHeight="86%">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>New group</div>
        <IconBtn name="x" onClick={onClose} />
      </div>

      {/* mode toggle */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 14, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 18 }}>
        {[['create', 'Create'], ['join', 'Join with code']].map(([m, lbl]) => {
          const on = mode === m;
          return <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: '10px', borderRadius: 10, border: 'none', cursor: 'pointer',
            fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 14, background: on ? 'var(--surface)' : 'transparent',
            color: on ? 'var(--clay)' : 'var(--ink-2)', boxShadow: on ? 'var(--shadow)' : 'none' }}>{lbl}</button>;
        })}
      </div>

      {mode === 'create' ? (
        <div>
          <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 8 }}>GROUP NAME</label>
          <input value={name} onChange={e => setName(e.target.value.slice(0, 40))} autoFocus placeholder="e.g. Tuesday Life Group" style={{
            width: '100%', height: 52, border: '1px solid var(--line)', borderRadius: 14, background: 'var(--surface)', padding: '0 16px',
            fontSize: 16.5, fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--ink)', outline: 'none', boxShadow: 'var(--shadow)' }} />

          <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '18px 0 8px' }}>TYPE</label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {GROUP_KINDS.map(k => <Chip key={k} active={!prayer && kind === k} onClick={() => { setKind(k); setPrayer(false); }}>{k}</Chip>)}
            <Chip active={prayer} onClick={() => setPrayer(true)} accent="var(--gold)">Prayer room</Chip>
          </div>

          <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', margin: '18px 0 10px' }}>COLOUR</label>
          <div style={{ display: 'flex', gap: 11 }}>
            {GROUP_ACCENTS.map(c => {
              const on = accent === c;
              return <button key={c} onClick={() => setAccent(c)} style={{ width: 36, height: 36, borderRadius: 999, background: c, cursor: 'pointer',
                border: on ? '2.5px solid var(--ink)' : '2px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {on ? <Icon name="check" size={16} stroke={2.8} color="#fff" /> : null}</button>;
            })}
          </div>

          <div style={{ display: 'flex', gap: 11, padding: 13, borderRadius: 14, background: 'color-mix(in oklab, var(--sage) 11%, var(--surface))',
            border: '1px solid color-mix(in oklab, var(--sage) 28%, transparent)', margin: '20px 0 16px' }}>
            <Icon name="shield" size={19} color="var(--sage)" style={{ flexShrink: 0, marginTop: 1 }} />
            <div style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5 }}>Members join anonymously with a code or QR. No phone numbers or emails are shared.</div>
          </div>

          <button onClick={make} style={primaryBtnC}><Icon name="plus" size={19} stroke={2.4} color="#fff" /> Create group</button>
        </div>
      ) : (
        <div>
          <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, lineHeight: 1.5, color: 'var(--ink-2)', margin: '0 0 16px', textWrap: 'pretty' }}>
            Enter the invite code your group leader gave you — or scan their QR.</p>
          <input value={code} onChange={e => setCode(e.target.value.slice(0, 12).toUpperCase())} autoFocus placeholder="INVITE CODE" style={{
            width: '100%', height: 60, border: '1px solid var(--line)', borderRadius: 14, background: 'var(--surface)', padding: '0 18px',
            fontSize: 24, fontFamily: 'monospace', fontWeight: 700, letterSpacing: '4px', color: 'var(--ink)', outline: 'none',
            boxShadow: 'var(--shadow)', textAlign: 'center' }} />
          <button onClick={join} disabled={!code.trim()} style={{ ...primaryBtnC, marginTop: 18, background: code.trim() ? 'var(--clay)' : 'var(--line)' }}>
            <Icon name="check" size={18} stroke={2.4} color="#fff" /> Join group</button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '18px 0' }}>
            <div style={{ flex: 1, height: 1, background: 'var(--line)' }} /><span style={{ fontSize: 12, color: 'var(--ink-3)', fontWeight: 600 }}>or</span><div style={{ flex: 1, height: 1, background: 'var(--line)' }} />
          </div>
          <button onClick={() => ctx.toast('Point your camera at the leader’s QR')} style={{ width: '100%', padding: 14, borderRadius: 14,
            border: '1px solid var(--line)', background: 'var(--surface)', color: 'var(--ink)', fontWeight: 700, fontSize: 15, cursor: 'pointer',
            fontFamily: 'var(--font-ui)', boxShadow: 'var(--shadow)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
            <Icon name="qr" size={19} color="var(--clay)" /> Scan a QR code</button>
        </div>
      )}
    </BottomSheet>
  );
}
const primaryBtnC = { width: '100%', padding: 16, borderRadius: 15, border: 'none', cursor: 'pointer', background: 'var(--clay)', color: '#fff',
  fontWeight: 700, fontSize: 16, fontFamily: 'var(--font-ui)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9 };

function ChatScreen({ ctx }) {
  const D = window.LumenData;
  const [nostr, setNostr] = useC(false);
  const [view, setView] = useC('groups');
  const [q, setQ] = useC('');
  const [groups, setGroups] = useC(D.GROUPS);
  const [newOpen, setNewOpen] = useC(false);
  const [givingLoad, setGivingLoad] = useC(0);
  const [givingGive, setGivingGive] = useC(0);
  const churchGroups = groups.filter(g => !g.church || g.church === ctx.activeChurch);
  const id = D.CHAT_IDENTITY;
  const onCount = D.RELAYS.filter(r => r.status === 'on').length;

  const ql = q.trim().toLowerCase();
  const groupHits = ql ? churchGroups.filter(g => g.name.toLowerCase().includes(ql) || g.kind.toLowerCase().includes(ql)) : [];
  const msgHits = ql ? Object.entries(D.GROUP_MESSAGES).flatMap(([gid, msgs]) =>
    msgs.filter(m => ((m.text || (m.verse && m.verse.text) || '')).toLowerCase().includes(ql))
        .map(m => ({ m, group: D.GROUPS.find(g => g.id === gid) }))
  ).filter(x => x.group) : [];
  const hi = (txt) => {
    const i = txt.toLowerCase().indexOf(ql);
    if (i < 0) return txt;
    return (<>{txt.slice(0, i)}<mark style={{ background: 'var(--hl-yellow)', color: 'inherit', borderRadius: 3, padding: '0 2px' }}>{txt.slice(i, i + ql.length)}</mark>{txt.slice(i + ql.length)}</>);
  };

  return (
    <ScreenScroll>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, animation: 'lumenFade .5s ease both' }}>
        <div style={{ minWidth: 0 }}>
          <h1 style={{ margin: '0 0 7px', fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, letterSpacing: '-.5px' }}>Community</h1>
          <ChurchPill ctx={ctx} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <IconBtn name="bell" badge={3} onClick={ctx.openNotifications} />
          <IconBtn name="plus" onClick={() => view === 'giving' ? setGivingGive(n => n + 1) : setNewOpen(true)} />
          <button onClick={ctx.openProfile} aria-label="Your profile" title={ctx.identity.name ? ctx.identity.name + ' · tap to edit' : 'Set your name'} style={{ border: 'none', background: 'none', padding: 0, cursor: 'pointer', borderRadius: 999, display: 'flex' }}>
            <UserAvatar av={ctx.identity.avatar} name={ctx.identity.name} size={40} ring={true} />
          </button>
        </div>
      </div>

      {/* segmented: Groups / Giving */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 15, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 20 }}>
        {[['groups', 'Groups', 'chat'], ['giving', 'Giving', 'bolt']].map(([gid, label, ic]) => {
          const on = view === gid;
          return (
            <button key={gid} onClick={() => setView(gid)} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, padding: '10px',
              borderRadius: 11, border: 'none', cursor: 'pointer', fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 14,
              background: on ? 'var(--surface)' : 'transparent', color: on ? 'var(--clay)' : 'var(--ink-2)',
              boxShadow: on ? 'var(--shadow)' : 'none', transition: 'all .2s',
            }}><Icon name={ic} size={17} stroke={on ? 2.1 : 1.8} fill={ic === 'bolt' && on} />{label}</button>
          );
        })}
      </div>

      {view === 'giving' ? (
        <GivingView ctx={ctx} balance={ctx.walletSats} setBalance={ctx.setWalletSats} history={ctx.giving} setHistory={ctx.setGiving} loadSignal={givingLoad} giveSignal={givingGive} />
      ) : (
      <React.Fragment>
      {/* search */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', height: 46, borderRadius: 14,
        background: 'var(--surface)', border: '1px solid var(--line)', boxShadow: 'var(--shadow)', marginBottom: 18 }}>
        <Icon name="study" size={19} color="var(--ink-3)" />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search messages & groups…" style={{
          flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 15, fontFamily: 'var(--font-ui)', color: 'var(--ink)' }} />
        {q ? <button onClick={() => setQ('')} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink-3)', display: 'flex' }}><Icon name="x" size={17} /></button> : null}
      </div>

      {ql ? (
      <div style={{ animation: 'lumenFade .3s ease both' }}>
        {groupHits.length === 0 && msgHits.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--ink-3)' }}>
            <Icon name="study" size={34} color="var(--ink-3)" />
            <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, marginTop: 10 }}>No matches for “{q}”</p>
          </div>
        ) : null}
        {groupHits.length ? <SectionLabel>Groups</SectionLabel> : null}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: groupHits.length ? 22 : 0 }}>
          {groupHits.map(g => (
            <div key={g.id} onClick={() => ctx.openGroup(g)} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 13, borderRadius: 16,
              background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)' }}>
              <div style={{ width: 42, height: 42, borderRadius: 13, background: `color-mix(in oklab, ${g.accent} 16%, var(--surface))`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: g.accent, flexShrink: 0 }}><Icon name={g.prayer ? 'pray' : 'chat'} size={22} /></div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>{hi(g.name)}</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>{g.kind} · {g.members} members</div>
              </div>
              <Icon name="chevR" size={17} color="var(--ink-3)" />
            </div>
          ))}
        </div>
        {msgHits.length ? <SectionLabel>Messages</SectionLabel> : null}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {msgHits.map(({ m, group }, i) => (
            <div key={i} onClick={() => ctx.openGroup(group)} style={{ padding: 13, borderRadius: 16, background: 'var(--surface-2)',
              border: '1px solid var(--line)', cursor: 'pointer' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 }}>
                <Avatar handle={m.handle} color={m.color} size={20} />
                <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-2)' }}>{m.me ? 'You' : m.handle}</span>
                <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>· {group.name}</span>
              </div>
              <p style={{ margin: 0, fontFamily: 'var(--font-read)', fontSize: 15, lineHeight: 1.45, color: 'var(--ink)' }}>{hi(m.text || (m.verse && m.verse.text) || '')}</p>
            </div>
          ))}
        </div>
      </div>
      ) : (
      <React.Fragment>
      <SectionLabel>Your groups</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, animation: 'lumenFade .5s ease .1s both' }}>
        {churchGroups.map(g => (
          <div key={g.id} onClick={() => ctx.openGroup(g)} style={{
            display: 'flex', alignItems: 'center', gap: 13, padding: 14, borderRadius: 18,
            background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)',
          }}>
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{ width: 50, height: 50, borderRadius: 16, background: `color-mix(in oklab, ${g.accent} 16%, var(--surface))`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: g.accent }}>
                <Icon name={g.prayer ? 'pray' : 'chat'} size={25} stroke={1.8} />
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{g.name}</span>
                <span style={{ fontSize: 11.5, color: 'var(--ink-3)', flexShrink: 0 }}>{g.when}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginTop: 2 }}>
                <span style={{ fontSize: 13, color: 'var(--ink-2)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>{g.last}</span>
                {g.unread ? <span style={{ flexShrink: 0, minWidth: 20, height: 20, padding: '0 6px', borderRadius: 999, background: 'var(--clay)', color: '#fff', fontSize: 11.5, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{g.unread}</span> : null}
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 3, display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ background: 'var(--surface-2)', border: '1px solid var(--line)', padding: '1px 7px', borderRadius: 999, fontWeight: 600 }}>{g.kind}</span>
                · {g.members} members
              </div>
            </div>
          </div>
        ))}
      </div>
      </React.Fragment>
      )}
      </React.Fragment>
      )}

      <NostrSheet open={nostr} onClose={() => setNostr(false)} ctx={ctx} />
      <NewGroupSheet open={newOpen} onClose={() => setNewOpen(false)} ctx={ctx}
        onCreate={(g) => { setGroups(gs => [{ ...g, church: ctx.activeChurch }, ...gs]); setNewOpen(false); ctx.toast('Group created'); setTimeout(() => ctx.openGroup(g), 250); }}
        onJoin={(g) => { setGroups(gs => gs.find(x => x.id === g.id) ? gs : [{ ...g, church: ctx.activeChurch }, ...gs]); setNewOpen(false); ctx.toast('Joined ' + g.name); setTimeout(() => ctx.openGroup(g), 250); }} />
    </ScreenScroll>
  );
}

// ── message bubble ──
function Bubble({ m, onAmen, ctx }) {
  const me = m.me;
  const bg = me ? 'var(--clay)' : 'var(--surface)';
  const fg = me ? '#fff' : 'var(--ink)';

  // verse share bubble
  if (m.kind === 'verse') {
    return (
      <Row me={me} m={m} ctx={ctx}>
        <div onClick={() => ctx.openShare(m.verse)} style={{
          maxWidth: 270, borderRadius: 18, padding: 0, overflow: 'hidden', cursor: 'pointer',
          background: 'linear-gradient(155deg, var(--clay), var(--clay-deep))', color: '#fff', boxShadow: 'var(--shadow)',
        }}>
          <div style={{ padding: '14px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5, fontWeight: 800, letterSpacing: '.6px', opacity: .9, marginBottom: 7 }}>
              <Icon name="sparkle" size={13} stroke={2} color="#fff" /> SHARED A VERSE</div>
            <p style={{ fontFamily: 'var(--font-read)', fontSize: 17, lineHeight: 1.42, margin: '0 0 9px', fontWeight: 500, textWrap: 'pretty' }}>“{m.verse.text}”</p>
            <div style={{ fontWeight: 700, fontSize: 12.5 }}>{m.verse.ref} · {m.verse.version}</div>
          </div>
        </div>
      </Row>
    );
  }

  // prayer request bubble
  if (m.kind === 'prayer') {
    return (
      <Row me={me} m={m} ctx={ctx}>
        <div style={{ maxWidth: 280, borderRadius: 18, padding: '13px 15px', background: 'var(--surface)',
          border: '1.5px solid color-mix(in oklab, var(--gold) 45%, var(--line))', boxShadow: 'var(--shadow)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5, fontWeight: 800, letterSpacing: '.5px', color: 'var(--gold)', marginBottom: 6 }}>
            <Icon name="pray" size={14} color="var(--gold)" /> PRAYER REQUEST</div>
          <p style={{ fontFamily: 'var(--font-read)', fontSize: 16, lineHeight: 1.5, margin: '0 0 11px', color: 'var(--ink)', textWrap: 'pretty' }}>{m.text}</p>
          <button onClick={() => onAmen(m.id)} style={{
            display: 'inline-flex', alignItems: 'center', gap: 7, border: '1px solid var(--line)',
            background: m._amened ? 'var(--clay-soft)' : 'var(--surface-2)', color: m._amened ? 'var(--clay-ink)' : 'var(--ink-2)',
            padding: '6px 12px', borderRadius: 999, cursor: 'pointer', fontWeight: 700, fontSize: 13, fontFamily: 'var(--font-ui)',
          }}>
            <Icon name="pray" size={15} fill={m._amened} /> Amen · {m.amens}</button>
        </div>
      </Row>
    );
  }

  return (
    <Row me={me} m={m} ctx={ctx}>
      <div style={{ maxWidth: 270, borderRadius: 18, padding: '10px 14px', background: bg, color: fg,
        border: me ? 'none' : '1px solid var(--line)', boxShadow: 'var(--shadow)',
        borderBottomRightRadius: me ? 5 : 18, borderBottomLeftRadius: me ? 18 : 5 }}>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: 14.5, lineHeight: 1.45, margin: 0, textWrap: 'pretty' }}>{m.text}</p>
      </div>
    </Row>
  );
}

function Row({ me, m, children, ctx }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: me ? 'flex-end' : 'flex-start', animation: 'lumenFade .3s ease both' }}>
      {!me ? <div onClick={() => ctx.openMember((m.handle || '').split(' ').slice(-1)[0])} style={{ display: 'flex', alignItems: 'center', gap: 7, margin: '0 0 4px 4px', cursor: 'pointer' }}>
        <Avatar handle={m.handle} color={m.color} size={22} />
        <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-2)' }}>{m.handle}</span>
        <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>{m.when}</span>
      </div> : null}
      {children}
      {me ? <span style={{ fontSize: 11, color: 'var(--ink-3)', margin: '3px 4px 0' }}>{m.when}</span> : null}
    </div>
  );
}

// ── conversation room (overlay) ──
function ChatRoom({ group, open, onClose, ctx }) {
  const [msgs, setMsgs] = useC([]);
  const [draft, setDraft] = useC('');
  const scRef = useCR();
  useCE(() => {
    if (group) setMsgs((window.LumenData.GROUP_MESSAGES[group.id] || []).map(m => ({ ...m })));
    setDraft('');
  }, [group]);
  useCE(() => {
    if (open && scRef.current) scRef.current.scrollTop = scRef.current.scrollHeight;
  }, [msgs, open]);

  if (!group) return null;

  const send = (extra) => {
    const id = window.LumenData.CHAT_IDENTITY;
    const base = { id: 'me-' + Date.now(), me: true, handle: id.handle, color: id.color, when: 'now' };
    setMsgs(prev => [...prev, { ...base, ...extra }]);
  };
  const sendText = () => { if (!draft.trim()) return; send({ text: draft.trim() }); setDraft(''); };
  const shareVerse = () => { send({ kind: 'verse', verse: { ...window.LumenData.VOTD } }); ctx.toast('Verse shared'); };
  const amen = (mid) => setMsgs(prev => prev.map(m => m.id === mid ? { ...m, _amened: !m._amened, amens: m.amens + (m._amened ? -1 : 1) } : m));

  return (
    <Overlay open={open} onClose={onClose}>
      {/* header */}
      <div style={{ paddingTop: 50, background: 'color-mix(in oklab, var(--surface) 92%, transparent)',
        backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', borderBottom: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '8px 14px 11px' }}>
          <button onClick={onClose} style={{ width: 38, height: 38, borderRadius: 12, border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name="chevL" size={22} /></button>
          <div style={{ width: 40, height: 40, borderRadius: 13, background: `color-mix(in oklab, ${group.accent} 16%, var(--surface))`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: group.accent, flexShrink: 0 }}>
            <Icon name={group.prayer ? 'pray' : 'chat'} size={22} /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, lineHeight: 1.1 }}>{group.name}</div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-3)', display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 6, height: 6, borderRadius: 999, background: 'var(--sage)' }} /> {group.members} anonymous · Nostr</div>
          </div>
          <IconBtn name="shield" onClick={() => ctx.toast('Everyone here is anonymous')} />
        </div>
      </div>

      {/* messages */}
      <div ref={scRef} className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 8px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ textAlign: 'center', margin: '2px 0 4px' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'var(--surface-2)', border: '1px solid var(--line)', color: 'var(--ink-3)', padding: '6px 13px', borderRadius: 999, fontSize: 11.5, fontWeight: 600 }}>
            <Icon name="lock" size={13} /> Messages are anonymous & relayed over Nostr</span>
        </div>
        {msgs.map(m => <Bubble key={m.id} m={m} onAmen={amen} ctx={ctx} />)}
      </div>

      {/* composer */}
      <div style={{ padding: '8px 12px 14px', borderTop: '1px solid var(--line)', background: 'var(--surface)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 9 }}>
          <button onClick={shareVerse} title="Share a verse" style={{ width: 44, height: 44, borderRadius: 14, border: '1px solid var(--line)', background: 'var(--surface-2)', cursor: 'pointer', color: 'var(--clay)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Icon name="sparkle" size={20} /></button>
          <textarea value={draft} onChange={e => setDraft(e.target.value)} rows={1}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); } }}
            placeholder="Message anonymously…" style={{
              flex: 1, resize: 'none', minHeight: 44, maxHeight: 96, padding: '12px 15px', borderRadius: 16,
              border: '1px solid var(--line)', background: 'var(--surface-2)', outline: 'none', fontSize: 14.5,
              fontFamily: 'var(--font-ui)', color: 'var(--ink)', lineHeight: 1.35 }} />
          <button onClick={sendText} style={{ width: 44, height: 44, borderRadius: 14, border: 'none',
            background: draft.trim() ? 'var(--clay)' : 'var(--line)', cursor: draft.trim() ? 'pointer' : 'default',
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'background .2s' }}>
            <Icon name="send" size={20} color="#fff" /></button>
        </div>
      </div>
    </Overlay>
  );
}

Object.assign(window, { ChatScreen, ChatRoom });
