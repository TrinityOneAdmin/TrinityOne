// stew-app.jsx — composes the steward surfaces onto a pan/zoom design canvas.

function StewApp() {
  return (
    <DesignCanvas>
      <DCSection id="console" title="1 · Steward Console — desktop web" subtitle="The full manager. Sign-in is guarded by the browser extension. Click through the wizard and switch tabs.">
        <DCArtboard id="wizard" label="Start a church — wizard" width={1180} height={744}>
          <StewWizard />
        </DCArtboard>
        <DCArtboard id="dashboard" label="Console — overview, giving, members…" width={1180} height={800}>
          <StewDashboard />
        </DCArtboard>
      </DCSection>

      <DCSection id="phone" title="2 · In-app steward mode — phone" subtitle="A light touch inside the member app — door-side tasks only. Tap “Show invite QR”.">
        <DCArtboard id="home" label="Steward home" width={360} height={702}>
          <StewPhone initial="home" />
        </DCArtboard>
        <DCArtboard id="invite" label="Invite a member" width={360} height={702}>
          <StewPhone initial="invite" />
        </DCArtboard>
      </DCSection>

      <DCSection id="extension" title="3 · Extension signer — browser popup" subtitle="Where the church key lives (your pick). Click Approve & sign; unlock with the PIN.">
        <DCArtboard id="request" label="Approve a signing request" width={760} height={560}>
          <StewExtensionRequest />
        </DCArtboard>
        <DCArtboard id="home-ext" label="Unlock & key home" width={760} height={560}>
          <StewExtensionHome />
        </DCArtboard>
      </DCSection>

      <DCSection id="relay" title="4 · TrinityOne Relay — desktop app" subtitle="The honest self-host path: a free app for Mac, Windows & Linux that runs the church's own relay. Toggle the OS; click Stop/Start.">
        <DCArtboard id="relay-setup" label="First-run setup" width={1040} height={720}>
          <RelayNodeApp initial="setup" />
        </DCArtboard>
        <DCArtboard id="relay-running" label="Running — status, log & network" width={1180} height={760}>
          <RelayNodeApp initial="running" />
        </DCArtboard>
      </DCSection>

      <DCSection id="custody" title="Key custody — extension vs phone bunker" subtitle="The phone-bunker (NIP-46) concept, side by side with the extension.">
        <DCArtboard id="explain" label="How custody works" width={1180} height={624}>
          <CustodyExplainer />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<StewApp />);
