// screens-search.jsx — universal search across scripture + lexicon, with selectable sources
const { useState: useSrch } = React;

const SEARCH_SOURCES = [
  { key: 'bibles', ic: 'read', t: 'All Bibles', s: '12 translations' },
  { key: 'lexicons', ic: 'lex', t: 'Lexicons', s: 'Greek & Hebrew' },
  { key: 'commentaries', ic: 'comment', t: 'Commentaries', s: '8 sets' },
  { key: 'notes', ic: 'pen', t: 'Your notes', s: '23 entries' },
];

function ScopeChip({ on, label, onClick }) {
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 13px', borderRadius: 999, cursor: 'pointer',
      border: on ? '1.5px solid var(--clay)' : '1px solid var(--line)',
      background: on ? 'var(--clay-soft)' : 'var(--surface)',
      color: on ? 'var(--clay-ink)' : 'var(--ink-3)', fontWeight: 700, fontSize: 12.5,
      fontFamily: 'var(--font-ui)', whiteSpace: 'nowrap', flexShrink: 0, transition: 'all .15s',
    }}>
      {on ? <Icon name="check" size={13} stroke={3} color="var(--clay)" /> : null}{label}
    </button>
  );
}

function SearchScreen({ ctx, onBack }) {
  const D = window.LumenData;
  const [q, setQ] = useSrch('');
  const [active, setActive] = useSrch('');
  const [scopes, setScopes] = useSrch(['bibles', 'lexicons', 'commentaries', 'notes']);
  const run = (term) => { setQ(term); setActive(term.toLowerCase()); };
  const toggle = (k) => setScopes(s => s.includes(k) ? (s.length > 1 ? s.filter(x => x !== k) : s) : [...s, k]);
  const res = D.SEARCH_RESULTS[active];

  const showLex = scopes.includes('lexicons') && res && res.lexicon.length > 0;
  const showScr = scopes.includes('bibles') && res && res.scripture.length > 0;
  const nothingInScope = res && !showLex && !showScr;

  return (
    <ScreenScroll top={56}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 11, margin: '0 0 14px' }}>
        {onBack ? <button onClick={onBack} aria-label="Back" style={{ width: 40, height: 40, borderRadius: 13, border: '1px solid var(--line)',
          background: 'var(--surface)', color: 'var(--ink)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow)', flexShrink: 0 }}>
          <Icon name="chevL" size={20} /></button> : null}
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, letterSpacing: '-.5px' }}>Search</h1>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 15px', height: 50, borderRadius: 16,
        background: 'var(--surface)', border: '1px solid var(--line)', boxShadow: 'var(--shadow)', marginBottom: 14 }}>
        <Icon name="study" size={20} color="var(--ink-3)" />
        <input value={q} onChange={e => setQ(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') run(q); }}
          placeholder="Search scripture, words, notes…" style={{
            flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 16,
            fontFamily: 'var(--font-ui)', color: 'var(--ink)',
          }} />
        {q ? <button onClick={() => { setQ(''); setActive(''); }} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink-3)', display: 'flex' }}><Icon name="x" size={18} /></button> : null}
      </div>

      {/* scope chips — always visible, select/deselect what's searched */}
      <div className="no-scrollbar" style={{ display: 'flex', gap: 8, overflowX: 'auto', margin: '0 -18px 18px', padding: '0 18px' }}>
        {SEARCH_SOURCES.map(src => <ScopeChip key={src.key} on={scopes.includes(src.key)} label={src.t} onClick={() => toggle(src.key)} />)}
      </div>

      {!res ? (
        <div style={{ animation: 'lumenFade .4s ease both' }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>TRY SEARCHING</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9, marginBottom: 28 }}>
            {D.SEARCH_SEED.map(s => <Chip key={s} onClick={() => run(s)}>{s}</Chip>)}
          </div>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>CHOOSE WHERE TO SEARCH</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {SEARCH_SOURCES.map(src => {
              const on = scopes.includes(src.key);
              return (
                <button key={src.key} onClick={() => toggle(src.key)} style={{
                  display: 'flex', alignItems: 'center', gap: 13, padding: 13, borderRadius: 16, width: '100%', textAlign: 'left',
                  cursor: 'pointer', fontFamily: 'var(--font-ui)', transition: 'all .15s',
                  background: on ? 'color-mix(in oklab, var(--clay) 7%, var(--surface))' : 'var(--surface-2)',
                  border: on ? '1.5px solid color-mix(in oklab, var(--clay) 38%, var(--line))' : '1px solid var(--line)',
                }}>
                  <div style={{ width: 36, height: 36, borderRadius: 11, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: on ? 'color-mix(in oklab, var(--clay) 15%, var(--surface))' : 'var(--surface)', color: on ? 'var(--clay)' : 'var(--ink-3)' }}>
                    <Icon name={src.ic} size={20} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14.5, color: 'var(--ink)' }}>{src.t}</div>
                    <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>{src.s}</div>
                  </div>
                  <div style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: on ? 'var(--clay)' : 'transparent', border: on ? 'none' : '2px solid var(--line)' }}>
                    {on ? <Icon name="check" size={15} stroke={3} color="#fff" /> : null}</div>
                </button>
              );
            })}
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 11, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="study" size={13} color="var(--ink-3)" /> Only the checked sources are searched.
          </div>
        </div>
      ) : (
        <div style={{ animation: 'lumenFade .4s ease both' }}>
          <div style={{ fontSize: 13.5, color: 'var(--ink-2)', marginBottom: 18 }}>
            <b style={{ color: 'var(--ink)' }}>{res.count}</b> results for “<b style={{ color: 'var(--clay)' }}>{active}</b>”
            <span style={{ color: 'var(--ink-3)' }}> · in {scopes.length} of {SEARCH_SOURCES.length} sources</span>
          </div>

          {nothingInScope ? (
            <div style={{ textAlign: 'center', padding: '40px 24px', color: 'var(--ink-3)' }}>
              <Icon name="study" size={30} color="var(--ink-3)" />
              <p style={{ margin: '12px 0 4px', fontSize: 15, fontWeight: 700, color: 'var(--ink-2)' }}>Nothing in the selected sources</p>
              <p style={{ margin: 0, fontSize: 13.5, lineHeight: 1.5 }}>Turn on <b>All Bibles</b> or <b>Lexicons</b> above to see results for this search.</p>
            </div>
          ) : null}

          {/* lexicon hit */}
          {showLex ? res.lexicon.map(id => {
            const e = D.LEXICON[id];
            return (
              <div key={id} onClick={() => ctx.openWord(id)} style={{
                borderRadius: 18, padding: 16, marginBottom: 18, cursor: 'pointer',
                background: 'var(--clay-soft)', border: '1px solid color-mix(in oklab, var(--clay) 25%, transparent)' }}>
                <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--clay-ink)', letterSpacing: '.5px' }}>LEXICON · STRONG'S {id}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
                  <span style={{ fontFamily: 'var(--font-read)', fontSize: 26, fontWeight: 500, color: 'var(--ink)' }}>{e.lemma}</span>
                  <span style={{ fontFamily: 'var(--font-read)', fontStyle: 'italic', color: 'var(--ink-2)' }}>{e.translit}</span>
                </div>
                <div style={{ fontSize: 14, color: 'var(--ink)', marginTop: 4, fontWeight: 500 }}>{e.short}</div>
              </div>
            );
          }) : null}

          {showScr ? (
            <React.Fragment>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)', letterSpacing: '.5px', marginBottom: 11 }}>IN SCRIPTURE</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
                {res.scripture.map((r, i) => (
                  <div key={i} onClick={() => ctx.openReader()} style={{
                    padding: 15, borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)' }}>
                    <div style={{ fontWeight: 700, color: 'var(--clay)', fontSize: 13.5, marginBottom: 4 }}>{r.ref}</div>
                    <p style={{ margin: 0, fontFamily: 'var(--font-read)', fontSize: 16.5, lineHeight: 1.5, color: 'var(--ink)', textWrap: 'pretty' }}
                      dangerouslySetInnerHTML={{ __html: r.text.replace(new RegExp(`(${active})`, 'gi'), '<mark style="background:var(--hl-yellow);color:inherit;border-radius:3px;padding:0 2px;">$1</mark>') }} />
                  </div>
                ))}
              </div>
            </React.Fragment>
          ) : null}
        </div>
      )}
    </ScreenScroll>
  );
}

window.SearchScreen = SearchScreen;
