// logos.jsx — Trinity One logo exploration marks + lockups
const C = {
  clay: '#C25A38', clayDeep: '#9C4327', clayInk: '#A8462A',
  gold: '#C8962E', goldSoft: '#E0B860',
  ink: '#221C16', ink2: '#6B6052',
  paper: '#F4EEE2', paperSoft: '#FBF6EC',
  mid: '#17120B', mid2: '#241C12',
  sage: '#5E8C6A',
};

// ─────────────────────────────────────────────
// MARKS  (100×100 viewBox, centered at 50,50)
// ─────────────────────────────────────────────

// A · AURAE — modern triquetra (trinity knot)
function MarkAurae({ size = 120, fg = C.clay, accent = C.gold, ring = true }) {
  const H = 33, W = 18.5;
  const top = 50 - H, c1 = 50 - 0.36 * H, c2 = 50 - 0.72 * H;
  const leaf = `M50 50 C ${50 - W} ${c1} ${50 - W} ${c2} 50 ${top} C ${50 + W} ${c2} ${50 + W} ${c1} 50 50 Z`;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      {ring ? <circle cx="50" cy="50" r="42" stroke={accent} strokeWidth="2.4" opacity="0.9" /> : null}
      {[0, 120, 240].map(a => (
        <path key={a} d={leaf} transform={`rotate(${a} 50 50)`} stroke={fg}
          strokeWidth="5" strokeLinejoin="round" strokeLinecap="round" />
      ))}
      <circle cx="50" cy="50" r="3.2" fill={accent} />
    </svg>
  );
}

// B · EMBER — one flame, three parts
function MarkEmber({ size = 120, body = C.clay, cut = C.paper, core = C.gold }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <path d="M50 15 C 67 41 74 53 74 62 A24 24 0 1 1 26 62 C 26 53 33 41 50 15 Z" fill={body} />
      <ellipse cx="50" cy="63" rx="8.5" ry="10" fill={core} opacity="0.95" />
      <path d="M50 19 L 36 78" stroke={cut} strokeWidth="3.4" strokeLinecap="round" />
      <path d="M50 19 L 64 78" stroke={cut} strokeWidth="3.4" strokeLinecap="round" />
    </svg>
  );
}

// C · MERIDIAN — T1 monogram badge
function MarkMeridian({ size = 120, fg = C.paper, accent = C.gold, stem = C.paper }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      {/* T crossbar */}
      <rect x="22" y="26" width="56" height="9" rx="4.5" fill={fg} />
      {/* shared stem (T stem = 1 body) */}
      <rect x="45.5" y="30" width="9" height="44" rx="4.5" fill={fg} />
      {/* 1 flag */}
      <path d="M37 40 L 46 30.5" stroke={fg} strokeWidth="9" strokeLinecap="round" />
      {/* 1 foot */}
      <rect x="36" y="69" width="28" height="9" rx="4.5" fill={accent} />
    </svg>
  );
}

// D · HALO — unity ring, three arcs + spark
function MarkHalo({ size = 120, fg = C.ink, accent = C.gold }) {
  const r = 36, circ = 2 * Math.PI * r; // ≈226.2
  const dash = `${circ / 3 - 16} 16`;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r={r} stroke={fg} strokeWidth="7" strokeLinecap="round"
        strokeDasharray={dash} transform="rotate(-90 50 50)" />
      <circle cx="50" cy="50" r="6.5" fill={accent} />
    </svg>
  );
}

const MARKS = { aurae: MarkAurae, ember: MarkEmber, meridian: MarkMeridian, halo: MarkHalo };

// ─────────────────────────────────────────────
// App-icon tile
// ─────────────────────────────────────────────
function Tile({ which, bg, render, size = 66, radius = 16 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: radius, background: bg, flexShrink: 0,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 4px 14px rgba(40,28,16,.18), inset 0 1px 0 rgba(255,255,255,.12)',
    }}>{render(size)}</div>
  );
}

// ─────────────────────────────────────────────
// Wordmark
// ─────────────────────────────────────────────
function Wordmark({ mark, color = C.ink, accent = C.clay, caps = false, weight = 700, tagline = true }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
      {mark}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <div style={{
          fontFamily: "'Sora', sans-serif", fontWeight: weight, color,
          fontSize: 25, lineHeight: 1, letterSpacing: caps ? '1.5px' : '-0.4px',
          textTransform: caps ? 'uppercase' : 'none', whiteSpace: 'nowrap',
        }}>
          {caps ? 'TRINITY ' : 'Trinity '}<span style={{ color: accent }}>{caps ? 'ONE' : 'One'}</span>
        </div>
        {tagline ? <div style={{
          fontFamily: "'Sora', sans-serif", fontWeight: 600, color: C.ink2,
          fontSize: 9.5, letterSpacing: '2px', textTransform: 'uppercase', marginTop: 1,
        }}>Read · Gather · Share</div> : null}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// One artboard's worth of presentation
// ─────────────────────────────────────────────
function LogoBoard({ id, code, idea, heroBg, heroFg, Mark, heroProps, tiles, wordMark }) {
  return (
    <div style={{ background: C.paperSoft, height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* hero */}
      <div style={{ background: heroBg, padding: '38px 0 34px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <Mark {...heroProps} size={150} />
        <span style={{ position: 'absolute', top: 14, left: 16, fontFamily: "'Sora',sans-serif", fontWeight: 700, fontSize: 12, letterSpacing: '0.5px', color: heroFg, opacity: 0.5 }}>{code}</span>
      </div>

      {/* body */}
      <div style={{ padding: '22px 24px 26px', display: 'flex', flexDirection: 'column', gap: 20, flex: 1 }}>
        {/* wordmark */}
        <div>{wordMark}</div>

        {/* app icons */}
        <div>
          <div style={{ fontFamily: "'Sora',sans-serif", fontSize: 10, fontWeight: 700, letterSpacing: '1.2px', color: C.ink2, textTransform: 'uppercase', marginBottom: 11 }}>App icon</div>
          <div style={{ display: 'flex', gap: 12 }}>{tiles}</div>
        </div>

        {/* idea */}
        <div style={{ marginTop: 'auto', paddingTop: 6, borderTop: `1px solid rgba(34,28,22,.1)` }}>
          <p style={{ margin: 0, fontFamily: "'Newsreader',serif", fontSize: 14.5, lineHeight: 1.5, color: C.ink, textWrap: 'pretty' }}>{idea}</p>
        </div>
      </div>
    </div>
  );
}

window.TrinityLogos = { C, MARKS, MarkAurae, MarkEmber, MarkMeridian, MarkHalo, Tile, Wordmark, LogoBoard };
