// screens-library.jsx — modules home (Bibles, Commentaries, Dictionaries, Devotionals, Books, Journals) + collections + journal
function ModuleTile({ m, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 13, padding: 14, borderRadius: 18,
      background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)'
    }}>
      <div style={{ width: 44, height: 44, borderRadius: 13, flexShrink: 0,
        background: `color-mix(in oklab, ${m.accent} 16%, var(--surface))`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: m.accent }}>
        <Icon name={m.icon} size={23} stroke={1.8} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15.5 }}>{m.name}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{m.count}</div>
      </div>
      <Icon name="chevR" size={18} color="var(--ink-3)" />
    </div>);

}

function LibraryScreen({ ctx }) {
  const D = window.LumenData;
  const [view, setView] = React.useState('library');
  return (
    <ScreenScroll>
      <h1 style={{ margin: '0 0 14px', fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, letterSpacing: '-.5px', animation: 'lumenFade .5s ease both' }}>Library</h1>

      {/* segmented: Library / Watch */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 15, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 20 }} data-comment-anchor="dd2234f87c-div-30-7">
        {[['library', 'Library', 'library'], ['watch', 'Watch', 'play']].map(([id, label, ic]) => {
          const on = view === id;
          return (
            <button key={id} onClick={() => setView(id)} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, padding: '10px',
              borderRadius: 11, border: 'none', cursor: 'pointer', fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: 14,
              background: on ? 'var(--surface)' : 'transparent', color: on ? 'var(--clay)' : 'var(--ink-2)',
              boxShadow: on ? 'var(--shadow)' : 'none', transition: 'all .2s'
            }}><Icon name={ic} size={17} stroke={on ? 2.1 : 1.8} />{label}</button>);

        })}
      </div>

      {view === 'watch' ? <WatchView ctx={ctx} /> : <LibraryHome ctx={ctx} />}
    </ScreenScroll>);

}

function LibraryHome({ ctx }) {
  const D = window.LumenData;
  return (
    <React.Fragment>
      {/* collections strip */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 22, animation: 'lumenFade .5s ease .05s both' }}>
        {D.COLLECTIONS.map((c) =>
        <button key={c.id} onClick={() => ctx.openCollection(c)} style={{
          flex: 1, minWidth: 0, padding: '13px 10px', borderRadius: 16, border: '1px solid var(--line)',
          background: 'var(--surface)', cursor: 'pointer', textAlign: 'left', color: 'var(--ink)', boxShadow: 'var(--shadow)'
        }}>
            <Icon name={c.icon} size={20} color="var(--clay)" />
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 21, fontWeight: 700, marginTop: 7, lineHeight: 1 }}>{c.count}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-2)', fontWeight: 600, marginTop: 3, lineHeight: 1.15 }}>{c.name}</div>
          </button>
        )}
      </div>

      <SectionLabel>Modules</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginBottom: 24, animation: 'lumenFade .5s ease .1s both' }}>
        {D.MODULES.map((m) => <ModuleTile key={m.id} m={m} onClick={() => ctx.openModule(m)} />)}
      </div>

      <SectionLabel action="+ New" onAction={() => ctx.newJournal()}>Recent journal</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11, animation: 'lumenFade .5s ease .15s both' }}>
        {(ctx.journalEntries || D.JOURNAL).length === 0 ? (
          <button onClick={() => ctx.newJournal()} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '30px 20px', borderRadius: 18,
            border: '1px dashed var(--line)', background: 'var(--surface-2)', cursor: 'pointer', color: 'var(--ink-3)', fontFamily: 'var(--font-ui)' }}>
            <Icon name="pen" size={24} color="var(--clay)" />
            <span style={{ fontWeight: 700, fontSize: 14.5, color: 'var(--ink-2)' }}>Start your first reflection</span>
          </button>
        ) : null}
        {(ctx.journalEntries || D.JOURNAL).map((j) =>
        <div key={j.id} onClick={() => ctx.openJournal(j)} style={{
          padding: 15, borderRadius: 18, background: 'var(--surface)', border: '1px solid var(--line)',
          cursor: 'pointer', position: 'relative', overflow: 'hidden', boxShadow: 'var(--shadow)'
        }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 5, background: j.color }} />
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--clay)' }}>{j.ref || 'Reflection'}</span>
              <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>{j.date}</span>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, marginBottom: 3 }}>{j.title}</div>
            <p style={{ margin: 0, fontFamily: 'var(--font-read)', fontSize: 15, lineHeight: 1.5, color: 'var(--ink-2)',
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{j.body}</p>
          </div>
        )}
      </div>
    </React.Fragment>);

}

// ── encrypted full backup (keys, journals, notes, highlights, books) ──
function BackupCard({ ctx }) {
  const [provider, setProvider] = React.useState(null); // null | 'iCloud' | 'Google Drive' | 'Dropbox'
  const [picking, setPicking] = React.useState(false);
  const PROVIDERS = [
  { id: 'iCloud', ic: 'cloud' },
  { id: 'Google Drive', ic: 'cloud' },
  { id: 'Dropbox', ic: 'cloud' }];

  const INCLUDED = [
  { ic: 'key', label: 'Recovery key', sealed: true },
  { ic: 'pen', label: 'Journals & notes' },
  { ic: 'marker', label: 'Highlights' },
  { ic: 'bookmark', label: 'Bookmarks' },
  { ic: 'books', label: 'Downloaded books' }];

  const connect = (id) => {setProvider(id);setPicking(false);ctx.toast('Backing up to ' + id + '…');};

  if (provider) {
    return (
      <div style={{ marginBottom: 13, borderRadius: 18, overflow: 'hidden',
        background: 'color-mix(in oklab, var(--sage) 13%, var(--surface))', border: '1px solid color-mix(in oklab, var(--sage) 30%, transparent)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 15px' }}>
          <div style={{ width: 38, height: 38, borderRadius: 12, flexShrink: 0, background: 'var(--sage)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="cloudCheck" size={21} stroke={2} color="#fff" /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--ink)' }}>Backed up to {provider}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-2)' }}>Everything encrypted · synced just now</div>
          </div>
          <button onClick={() => setProvider(null)} style={{ border: 'none', background: 'none', color: 'var(--ink-3)', fontWeight: 700, fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Manage</button>
        </div>
      </div>);

  }

  return (
    <div style={{ marginBottom: 13, borderRadius: 18, background: 'var(--surface-2)', border: '1px solid var(--line)', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 15px 11px' }} data-comment-anchor="67df77a64d-div-123-7">
        <div style={{ width: 38, height: 38, borderRadius: 12, flexShrink: 0, background: 'color-mix(in oklab, var(--clay) 14%, var(--surface))', color: 'var(--clay)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="cloud" size={21} stroke={1.9} /></div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--ink)' }}>Back up everything</div>
          <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.35 }}>One encrypted copy of your whole library — restore on a new phone in seconds.</div>
        </div>
        {!picking ? <button onClick={() => setPicking(true)} style={{ border: 'none', background: 'var(--clay)', color: '#fff',
          fontWeight: 700, fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-ui)', padding: '9px 14px', borderRadius: 11, flexShrink: 0 }}>Back up</button> : null}
      </div>

      {/* what's included */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, padding: '0 15px 11px' }}>
        {INCLUDED.map((it) =>
        <span key={it.label} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 10px', borderRadius: 999,
          background: 'var(--surface)', border: '1px solid var(--line)', fontSize: 11.5, fontWeight: 600, color: 'var(--ink-2)' }}>
            <Icon name={it.ic} size={13} color={it.sealed ? 'var(--clay)' : 'var(--ink-3)'} />{it.label}
            {it.sealed ? <Icon name="lock" size={11} color="var(--clay)" /> : null}
          </span>
        )}
      </div>

      {/* security note — always visible */}
      <div style={{ display: 'flex', gap: 8, padding: '0 15px 13px', fontSize: 11.5, color: 'var(--ink-3)', lineHeight: 1.45 }}>
        <Icon name="shield" size={14} color="var(--sage)" style={{ flexShrink: 0, marginTop: 1 }} />
        <span>Sealed on this phone before it uploads. Your <b style={{ color: 'var(--ink-2)' }}>recovery key</b> is locked with a passphrase only you know — not even the cloud provider can read it.</span>
      </div>

      {picking ?
      <div style={{ display: 'flex', flexDirection: 'column', gap: 7, padding: '0 12px 12px', animation: 'lumenFade .2s ease both' }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.4px', color: 'var(--ink-3)', padding: '0 3px 2px', textTransform: 'uppercase' }}>Choose where it's stored</div>
          {PROVIDERS.map((p) =>
        <button key={p.id} onClick={() => connect(p.id)} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '11px 13px', width: '100%', textAlign: 'left',
          borderRadius: 13, background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', fontFamily: 'var(--font-ui)', boxShadow: 'var(--shadow)' }}>
              <Icon name={p.ic} size={19} color="var(--ink-2)" />
              <span style={{ flex: 1, fontWeight: 700, fontSize: 14, color: 'var(--ink)' }}>{p.id}</span>
              <Icon name="chevR" size={17} color="var(--ink-3)" />
            </button>
        )}
        </div> :
      null}
    </div>);

}

// ── journal entry overlay ──
function JournalView({ entry, open, onClose, ctx }) {
  if (!entry) return null;
  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px 6px' }}>
          <IconBtn name="chevD" onClick={onClose} />
          <IconBtn name="pen" onClick={() => { onClose(); setTimeout(() => ctx && ctx.editJournal(entry), 220); }} />
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '12px 22px 30px' }}>
        <span style={{ display: 'inline-block', background: entry.color, color: 'var(--ink)', padding: '5px 12px',
          borderRadius: 999, fontSize: 12.5, fontWeight: 700, marginBottom: 14 }}>{entry.ref || 'Reflection'}</span>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, margin: '0 0 6px', lineHeight: 1.1 }}>{entry.title}</h1>
        <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 22 }}>{entry.date}</div>
        <p style={{ fontFamily: 'var(--font-read)', fontSize: 19, lineHeight: 1.65, color: 'var(--ink)', textWrap: 'pretty', whiteSpace: 'pre-wrap' }}>{entry.body}</p>
      </div>
    </Overlay>);

}

// ── journal editor (create / edit / delete) ──
const JOURNAL_COLORS = ['var(--hl-yellow)', 'var(--hl-green)', 'var(--hl-pink)', 'var(--hl-blue)', 'var(--hl-clay)'];

function JournalEditor({ entry, open, onClose, ctx }) {
  const editing = !!(entry && entry.id);
  const [ref, setRef] = React.useState('');
  const [title, setTitle] = React.useState('');
  const [body, setBody] = React.useState('');
  const [color, setColor] = React.useState('var(--hl-yellow)');
  React.useEffect(() => {
    if (open) {
      setRef((entry && entry.ref) || '');
      setTitle((entry && entry.title) || '');
      setBody((entry && entry.body) || '');
      setColor((entry && entry.color) || 'var(--hl-yellow)');
    }
  }, [open, entry && entry.id]);

  const canSave = !!(title.trim() || body.trim());
  const save = () => {
    if (!canSave) return;
    ctx.saveJournal({
      id: (entry && entry.id) || ('j' + Date.now()),
      date: (entry && entry.date) || 'Today',
      ref: ref.trim(), color,
      title: title.trim() || 'Untitled',
      body: body.trim(),
    });
    onClose();
    ctx.toast(editing ? 'Journal updated' : 'Journal saved');
  };
  const del = () => { ctx.deleteJournal(entry.id); onClose(); ctx.toast('Entry deleted'); };

  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50, flexShrink: 0, borderBottom: '1px solid var(--line-2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '8px 14px 11px' }}>
          <button onClick={onClose} style={{ border: 'none', background: 'none', color: 'var(--ink-2)', fontWeight: 600, fontSize: 15, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>Cancel</button>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{editing ? 'Edit entry' : 'New entry'}</div>
          <button onClick={save} disabled={!canSave} style={{ border: 'none', borderRadius: 11, padding: '8px 17px', background: 'var(--clay)', color: '#fff',
            fontWeight: 700, fontSize: 14, cursor: canSave ? 'pointer' : 'default', fontFamily: 'var(--font-ui)', opacity: canSave ? 1 : .4 }}>Save</button>
        </div>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '16px 20px 30px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, height: 42, padding: '0 13px', borderRadius: 12, background: 'var(--surface-2)', border: '1px solid var(--line)', marginBottom: 16 }}>
          <Icon name="link" size={16} color="var(--clay)" />
          <input value={ref} onChange={e => setRef(e.target.value)} placeholder="Link a verse — e.g. John 1:4 (optional)" style={{
            flex: 1, minWidth: 0, border: 'none', background: 'none', outline: 'none', fontSize: 14, fontWeight: 600, color: 'var(--ink)', fontFamily: 'var(--font-ui)' }} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 18 }}>
          <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-3)' }}>Marker</span>
          <div style={{ display: 'flex', gap: 9 }}>
            {JOURNAL_COLORS.map(c => (
              <button key={c} onClick={() => setColor(c)} aria-label="marker color" style={{ width: 28, height: 28, borderRadius: 999, background: c, cursor: 'pointer',
                border: color === c ? '2.5px solid var(--ink)' : '2px solid var(--line)' }} />
            ))}
          </div>
        </div>
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" style={{ width: '100%', border: 'none', background: 'none', outline: 'none',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 25, letterSpacing: '-.4px', color: 'var(--ink)', marginBottom: 10, padding: 0 }} />
        <textarea value={body} onChange={e => setBody(e.target.value)} placeholder="Write your reflection…" rows={11} style={{ width: '100%', border: 'none', background: 'none', outline: 'none', resize: 'none',
          fontFamily: 'var(--font-read)', fontSize: 18, lineHeight: 1.65, color: 'var(--ink)', minHeight: 230 }} />
        {editing ? (
          <button onClick={del} style={{ marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 8, padding: '11px 16px', borderRadius: 12,
            border: '1px solid color-mix(in oklab, var(--clay) 30%, var(--line))', background: 'var(--surface)', color: 'var(--clay-ink)', fontWeight: 700, fontSize: 13.5, cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>
            <Icon name="trash" size={16} color="var(--clay)" /> Delete entry</button>
        ) : null}
      </div>
    </Overlay>);

}

// ── module collection (drill-in from Library) with scoped search ──
function ModuleView({ module, open, onClose, ctx }) {
  const D = window.LumenData;
  const [q, setQ] = React.useState('');
  const [cat, setCat] = React.useState('All');
  React.useEffect(() => { if (open) { setQ(''); setCat('All'); } }, [open, module && module.id]);
  if (!module) return null;

  const raw = module.id === 'journals'
    ? (ctx.journalEntries || D.JOURNAL).map(j => ({ id: j.id, name: j.title, sub: (j.ref || 'Reflection') + ' · ' + j.date, journal: j, downloaded: true }))
    : (D.MODULE_ITEMS[module.id] || []);
  const cats = ['All', ...Array.from(new Set(raw.map(it => it.cat).filter(Boolean)))];
  const catFiltered = cat === 'All' ? raw : raw.filter(it => it.cat === cat);
  const ql = q.trim().toLowerCase();
  const items = ql ? catFiltered.filter(it => (it.name + ' ' + (it.sub || '')).toLowerCase().includes(ql)) : catFiltered;
  const accent = module.accent;

  const openItem = (it) => {
    if (it.journal) { onClose(); setTimeout(() => ctx.openJournal(it.journal), 200); return; }
    if (module.id === 'dictionaries' && it.id === 'strongs') { onClose(); setTimeout(() => ctx.openConcordance(), 200); return; }
    if (module.id === 'bibles') { ctx.toast(it.current ? it.abbr + ' is your reading version' : it.abbr + ' set as your reading version'); return; }
    if (module.id === 'books') { ctx.openBook(it); return; }
    ctx.toast('Opening ' + it.name);
  };

  return (
    <Overlay open={open} onClose={onClose}>
      {/* header */}
      <div style={{ paddingTop: 50, flexShrink: 0, background: 'color-mix(in oklab, var(--paper) 92%, transparent)', borderBottom: '1px solid var(--line-2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 16px 12px' }}>
          <IconBtn name="chevL" onClick={onClose} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 23, fontWeight: 700, letterSpacing: '-.4px', lineHeight: 1.1 }}>{module.name}</h1>
            <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 1 }}>{raw.length} in your library</div>
          </div>
          <div style={{ width: 40, height: 40, borderRadius: 13, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: `color-mix(in oklab, ${accent} 16%, var(--surface))`, color: accent }}>
            <Icon name={module.icon} size={22} stroke={1.8} /></div>
        </div>
        {/* scoped search */}
        <div style={{ padding: '0 16px 13px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, height: 42, padding: '0 14px', borderRadius: 13,
            background: 'var(--surface-2)', border: '1px solid var(--line)' }}>
            <Icon name="study" size={17} color="var(--ink-3)" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder={`Search ${module.name}`} style={{
              flex: 1, minWidth: 0, border: 'none', background: 'none', outline: 'none', fontSize: 14.5,
              color: 'var(--ink)', fontFamily: 'var(--font-ui)' }} />
            {q ? <button onClick={() => setQ('')} aria-label="Clear" style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink-3)', display: 'flex', padding: 2 }}><Icon name="x" size={16} /></button> : null}
          </div>
        </div>
        {cats.length > 1 ? (
          <div className="no-scrollbar" style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 16px 12px' }}>
            {cats.map(c => <Chip key={c} active={cat === c} onClick={() => setCat(c)} accent={accent}>{c}</Chip>)}
          </div>
        ) : null}
      </div>

      {/* list */}
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 30px' }}>
        {items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--ink-3)' }}>
            <Icon name="study" size={30} color="var(--ink-3)" />
            <p style={{ margin: '12px 0 0', fontSize: 14.5 }}>No matches in {module.name}</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {items.map(it => (
              <div key={it.id} onClick={() => openItem(it)} style={{
                display: 'flex', alignItems: 'center', gap: 13, padding: 13, borderRadius: 16,
                background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)' }}>
                <div style={{ width: 42, height: 42, borderRadius: 12, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: `color-mix(in oklab, ${accent} ${it.current ? 22 : 13}%, var(--surface))`, color: accent }}>
                  {it.abbr ? <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: it.abbr.length > 3 ? 12 : 13.5, letterSpacing: '-.3px' }}>{it.abbr}</span>
                    : <Icon name={module.icon} size={21} stroke={1.8} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14.5, color: 'var(--ink)', lineHeight: 1.18,
                    display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{it.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{it.sub}</div>
                </div>
                {it.current ? (
                  <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '.3px', color: '#fff', background: accent, padding: '4px 10px', borderRadius: 999, flexShrink: 0 }}>CURRENT</span>
                ) : it.downloaded ? (
                  <Icon name="cloudCheck" size={20} color="var(--sage)" style={{ flexShrink: 0 }} />
                ) : (
                  <button onClick={(e) => { e.stopPropagation(); ctx.toast('Downloading ' + it.name + '…'); }} style={{
                    flexShrink: 0, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 10,
                    border: '1px solid var(--line)', background: 'var(--surface-2)', color: 'var(--ink-2)', fontWeight: 700, fontSize: 12.5,
                    cursor: 'pointer', fontFamily: 'var(--font-ui)' }}>
                    <Icon name="cloud" size={15} color="var(--ink-3)" /> Get</button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </Overlay>);

}

// ── collection drill-in (Highlights / Bookmarks / Notes / Cross refs) ──
function CollectionView({ coll, open, onClose, ctx }) {
  const D = window.LumenData;
  const [q, setQ] = React.useState('');
  React.useEffect(() => { if (open) setQ(''); }, [open, coll && coll.id]);
  if (!coll) return null;
  const raw = D.COLLECTION_ITEMS[coll.id] || [];
  const ql = q.trim().toLowerCase();
  const items = ql ? raw.filter(it => (it.ref + ' ' + (it.text || '')).toLowerCase().includes(ql)) : raw;
  const isNotes = coll.id === 'notes';
  const isXref = coll.id === 'crossrefs';
  const blurb = { highlights: 'Verses you’ve marked', bookmarks: 'Saved for later', notes: 'Your reflections in the margin', crossrefs: 'Where scripture echoes scripture' }[coll.id];

  const jump = (it) => { onClose(); setTimeout(() => ctx.openReader(), 200); ctx.toast('Jumping to ' + it.ref); };

  return (
    <Overlay open={open} onClose={onClose}>
      <div style={{ paddingTop: 50, flexShrink: 0, background: 'color-mix(in oklab, var(--paper) 92%, transparent)', borderBottom: '1px solid var(--line-2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 16px 12px' }}>
          <IconBtn name="chevL" onClick={onClose} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 23, fontWeight: 700, letterSpacing: '-.4px', lineHeight: 1.1 }}>{coll.name}</h1>
            <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 1 }}>{raw.length} · {blurb}</div>
          </div>
          <div style={{ width: 40, height: 40, borderRadius: 13, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'color-mix(in oklab, var(--clay) 14%, var(--surface))', color: 'var(--clay)' }}><Icon name={coll.icon} size={21} stroke={1.8} /></div>
        </div>
        <div style={{ padding: '0 16px 13px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, height: 42, padding: '0 14px', borderRadius: 13, background: 'var(--surface-2)', border: '1px solid var(--line)' }}>
            <Icon name="study" size={17} color="var(--ink-3)" />
            <input value={q} onChange={ev => setQ(ev.target.value)} placeholder={`Search ${coll.name}`} style={{
              flex: 1, minWidth: 0, border: 'none', background: 'none', outline: 'none', fontSize: 14.5, color: 'var(--ink)', fontFamily: 'var(--font-ui)' }} />
            {q ? <button onClick={() => setQ('')} aria-label="Clear" style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--ink-3)', display: 'flex', padding: 2 }}><Icon name="x" size={16} /></button> : null}
          </div>
        </div>
      </div>

      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 30px' }}>
        {items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--ink-3)' }}>
            <Icon name={coll.icon} size={30} color="var(--ink-3)" />
            <p style={{ margin: '12px 0 0', fontSize: 14.5 }}>No matches in {coll.name}</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {items.map((it, i) => (
              <div key={i} onClick={() => jump(it)} style={{
                padding: 15, borderRadius: 16, background: 'var(--surface)', border: '1px solid var(--line)', cursor: 'pointer', boxShadow: 'var(--shadow)',
                position: 'relative', overflow: 'hidden', paddingLeft: it.color ? 18 : 15 }}>
                {it.color ? <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 5, background: it.color }} /> : null}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontWeight: 700, color: 'var(--clay)', fontSize: 13.5 }}>
                    {isXref ? <Icon name="link" size={14} color="var(--clay)" /> : null}
                    {coll.id === 'bookmarks' ? <Icon name="bookmark" size={13} color="var(--clay)" fill /> : null}
                    {it.ref}
                  </span>
                  {isNotes ? <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>{it.date}</span> : <Icon name="chevR" size={16} color="var(--ink-3)" />}
                </div>
                <p style={{ margin: 0, fontFamily: isXref ? 'var(--font-ui)' : 'var(--font-read)', fontSize: isXref ? 13.5 : 16, fontWeight: isXref ? 600 : 400,
                  lineHeight: 1.5, color: isXref ? 'var(--ink-2)' : 'var(--ink)', textWrap: 'pretty',
                  display: '-webkit-box', WebkitLineClamp: isNotes ? 3 : 4, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{it.text}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </Overlay>);

}

Object.assign(window, { LibraryScreen, JournalView, JournalEditor, BackupCard, ModuleView, CollectionView });